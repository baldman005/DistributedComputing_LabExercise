//Phase types for the 2 phase algorithm
public enum PhaseType{
	request, prepare, commit, reply, mine, elect
}
