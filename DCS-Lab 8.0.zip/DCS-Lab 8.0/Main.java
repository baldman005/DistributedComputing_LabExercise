import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.rmi.AlreadyBoundException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

public class Main {
	//function to find out whether the simulation has stopped(false) or not(true)
	private static boolean SimulationRunning(ArrayList<Thread> t){
		//UPDATE
		for(int i=0; i<t.size(); i++)
			if(t.get(i).isAlive())
				return true;
		
		return false;
	}
	
	private static ArrayList<String> Servers_URLs = new ArrayList<String>();
	private static ArrayList<String> Clients_URLs = new ArrayList<String>();
	private static final int MAP_WIDTH = 10;
	private static final int MAP_HEIGHT = 10;
	private static final int Dragons_N = 2;
	private static final int MinPlayer_N = 10;
	
	public static void main(String args[]) throws FileNotFoundException, UnsupportedEncodingException   {		
		int Servers_N = 1;			//Number of servers
		int Clients_N = MinPlayer_N;//Number of Clients
		int host_id = 0;			//Host server id
		
		//if no valid host_id is given, the default is 0
		if(host_id > Servers_N-1 || host_id < 0){
			host_id = 0;
		}
		
		//adds the Servers URLs to the list
		for(int i=0; i < Servers_N; i++){
			Servers_URLs.add("rmi://localhost:" + (1099+i) + "/s" + i);
		}
		
		//adds the Clients URLs to the list
		for(int i=0; i < Clients_N; i++){
			Clients_URLs.add("rmi://localhost:" + (1099+Servers_N+i) + "/c" + i);
		}
		
		ArrayList<Thread> t = new ArrayList<Thread>();
		
		
		try {	
		//creates the servers
		ArrayList<Server> servers = new ArrayList<Server>();
		for(int i=0; i<Servers_N; i++){
			Machine machine = new Machine(i, MAP_WIDTH, MAP_HEIGHT, Servers_URLs.get(i), Servers_N,0,1,host_id);
			servers.add(new Server(Servers_URLs, Dragons_N, MinPlayer_N, machine,Servers_URLs.get(i),"server"+i+".res"));
		}
		
		//creates the RMI registries
		ArrayList<Registry> reg = new ArrayList<Registry>();
		for(int i=0; i<(Servers_N + Clients_N); i++)
			reg.add( java.rmi.registry.LocateRegistry.createRegistry(1099+i));
		
		//binds a remote reference to the specified name in the registries
		for(int i=0; i<Servers_N; i++)
			reg.get(i).bind(Servers_URLs.get(i), servers.get(i));
		
		//binds the Servers URL to the servers
		for(int i=0; i<Servers_N; i++)
			java.rmi.Naming.bind(Servers_URLs.get(i), servers.get(i));
		
		
		//creates the clients
		ArrayList<Client> clients = new ArrayList<Client>();
		for(int i=0; i<Clients_N; i++) {
			Machine machine = new Machine(i + Servers_N, MAP_WIDTH, MAP_HEIGHT, Clients_URLs.get(i), Servers_N,0,0,host_id);

			clients.add(new Client(Servers_URLs ,machine,Clients_URLs.get(i),"client"+i+".res"));
		}
		
		//binds a remote reference to the specified name in the registries	
		for(int i=0; i<Clients_N; i++)
			reg.get(i+Servers_N).bind(Clients_URLs.get(i), clients.get(i));
		
		//binds the Clients URL to the clients
		for(int i=0; i<Clients_N; i++)
			java.rmi.Naming.bind(Clients_URLs.get(i), clients.get(i));
	    
	    //creates the threads and starts them
		//UPDATE
		for(int i=0; i<Servers_N; i++){
			t.add(new Thread(servers.get(i)));
			t.get(i).start();
		}
		
		Thread.sleep(1500);
		
		for(int i=0; i<Clients_N; i++){
			Thread.sleep(5);
			t.add(new Thread(clients.get(i)));
			t.get(i+Servers_N).start();
		}
	    
	    //waits for the simulation to end
		while(SimulationRunning(t)) {
	    	Thread.sleep(100);
		}
	    
	    //unbinds the registries references
		for(int i=0; i<Servers_N; i++)
	    	reg.get(i).unbind(Servers_URLs.get(i));
		for(int i=0; i<Clients_N; i++)
			reg.get(i+Servers_N).unbind(Clients_URLs.get(i));
		
		//unexports the registries
		for(int i=0; i<(Servers_N + Clients_N); i++)
			UnicastRemoteObject.unexportObject(reg.get(i),true);

		} catch ( RemoteException| MalformedURLException| 
				AlreadyBoundException | NotBoundException  
				| InterruptedException e) {
			e.printStackTrace();
		}
		//exits to kill the RMI ports
		System.exit(0);		
	}

}
