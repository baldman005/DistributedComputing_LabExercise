import java.io.Serializable;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;

public class Command implements Serializable {
	private static final long serialVersionUID = 1L;
	private CommandType type;
	private ArrayList<Integer> args_int;
	//send copy of map
	private ArrayList<Unit> units;
	
	//constructor for gameStart or falseStart
	protected Command(CommandType type, int origin_id){
		this.type = type;
		args_int = new ArrayList<Integer>();
		args_int.add(origin_id);
	}
	
	//constructor with unit to be removed (for remove)
	protected Command(CommandType type, int sourceX,int sourceY, int origin_id){
		this.type = type;
		args_int = new ArrayList<Integer>();
		args_int.add(sourceX);
		args_int.add(sourceY);
		args_int.add(origin_id);
	}
	
	//constructor 1 value of coordinates, currHP, maxHP, AP, the unit type (0 dragon, 1 player)(for spawn), and the id of the client/server
	protected Command(CommandType type, int currHP, int maxHP, int AP, int x, int y, UnitType unittype, int unit_id, int origin_id){
		this.type = type;
		args_int = new ArrayList<Integer>();
		args_int.add(currHP);
		args_int.add(maxHP);
		args_int.add(AP);
		args_int.add(x);
		args_int.add(y);
		switch(unittype){
			case dragon:
				args_int.add(0);
				break;
			case player:
				args_int.add(1);
				break;
		}
		args_int.add(unit_id);
		args_int.add(origin_id);
	}
	
	//constructor with only 2 values of coordinates(for attack, heal)
	protected Command(CommandType type, int sourceX, int sourceY,int  targetX, int targetY, int diffAP, int origin_id){
		this.type = type;
		args_int = new ArrayList<Integer>();
		args_int.add(sourceX);
		args_int.add(sourceY);
		args_int.add(targetX);
		args_int.add(targetY);
		args_int.add(diffAP);
		args_int.add(origin_id);
	}
	
	//constructor with only 2 values of coordinates(for move)
	protected Command(CommandType type, int sourceX, int sourceY,int  targetX, int targetY, int origin_id){
		this.type = type;
		args_int = new ArrayList<Integer>();
		args_int.add(sourceX);
		args_int.add(sourceY);
		args_int.add(targetX);
		args_int.add(targetY);
		args_int.add(origin_id);
	}
	
	//constructor for sending an image of the battlefield map
	protected Command(CommandType type, ArrayList<Unit> units, int origin_id) {
		this.type = type;
		this.units = units;
		args_int = new ArrayList<Integer>();
		args_int.add(origin_id);
	}
	
	//return map of battlefield
	public ArrayList<Unit> getUnits(){
		return this.units;
	}
	
	//return command type
	public CommandType getType(){
		return type;
	}
	
	//return sender id
	public int getOriginId(){
		return arg(args_int.size() - 1);
	}
	
	//return integer argument i
	public int arg(int i){
		if (i < args_int.size())
			return args_int.get(i);
		return -1;
	}
	
	//checks if content of another command is equal to its content
	public boolean sameAs(Command c){
		if(c.type != this.type)
			return false;
		for(int i = 0; i < c.args_int.size(); i++)
			if(c.args_int.get(i) != this.args_int.get(i))
				return false;
		
		return true;
	}
	
	//method to process a command 
	//it is necessary to send the Inverse command if processing a normal attack or heal (to take care of new HP < 0 or > maxHP)
	public Unit processCommand(Battlefield battlefield, Machine machine, Command inverse, int timestamp, int step_pos, boolean beenProcessed){
		Unit new_unit = null;
		Unit source = null;
		Unit target = null;
		boolean success = false;
		int x, y, unit_id, diffAP;
				
		switch(this.getType()){
			case spawn:
				UnitType unittype;
				if(this.arg(5)==1)
					unittype = UnitType.player;
				else
					unittype = UnitType.dragon;
				
				x = this.arg(3);
				y = this.arg(4);
				
				//checks if it needs to create a new or uses the received
				if(this.arg(6) == -1 || battlefield.idExist(this.arg(6)))
					unit_id = battlefield.getCurrID();
				else
					unit_id = this.arg(6);
				if(battlefield.posFree(x, y)){
					new_unit = new Unit(this.arg(0),this.arg(1),this.arg(2),x,y,unit_id,unittype,battlefield);
					success = battlefield.spawnUnit(new_unit);
				}
				
				//if is host and failed to spawn, will try to do it again
				if(!success){ 
					if(machine.id == machine.host_id)
						machine.val_buffer.addCommit(PhaseType.request, new Step(this,inverse,timestamp),false);
					return null;
				}
				
				if(machine.id != this.arg(7))
					new_unit = null;
				
				break;
			case remove:
				source = battlefield.getUnit(this.arg(0), this.arg(1));
				battlefield.removeUnit(source, inverse!=null);
				break;
			case attack:				
				source = battlefield.getUnit(this.arg(0), this.arg(1));
				target = battlefield.getUnit(this.arg(2), this.arg(3));
				if(source != null && source.checkRunning()){
					if(inverse != null)
						diffAP = source.attackUnit(target,this.arg(5),timestamp,this.getOriginId());
					else
						diffAP = source.attackUnit(target,this.arg(5),timestamp,-1);

					if(inverse != null)
						inverse.args_int.set(5, diffAP);
				}
				break;
			case heal:
				source = battlefield.getUnit(this.arg(0), this.arg(1));
				target = battlefield.getUnit(this.arg(2), this.arg(3));
				if(source != null && source.checkRunning()){
					//means that is reviving (doing an inverse command)
					if(inverse == null){
						diffAP = source.healUnit(target,this.arg(5),timestamp,true);
					}
					else
						diffAP = source.healUnit(target,this.arg(5),timestamp,false);
						
					if(inverse != null)
						inverse.args_int.set(5, diffAP);				
				}
				break;
			case move:
				source = battlefield.getUnit(this.arg(0),this.arg(1));
				if(source != null && source.checkRunning())
					source.moveUnit(this.arg(2),this.arg(3));
				break;
			case gameStart:
				machine.startGame();
				System.out.println(machine.owner + ": " +"BATTLE BEGINS");
				machine.addOutput("BATTLE BEGINS");
				break;
			case falseStart:
				machine.gameStarted = false;
				machine.pauseUnits();
				System.out.println(machine.owner + ": " +"FALSE START");
				machine.addOutput("FALSE START");
				break;
			default:
				break;
		}
		
		return new_unit;
	}
}