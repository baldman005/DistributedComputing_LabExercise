public enum PhaseType{
	request, prepare, commit, reply,
}
