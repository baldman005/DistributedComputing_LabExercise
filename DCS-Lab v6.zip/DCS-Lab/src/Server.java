import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

//class Server
public class Server extends UnicastRemoteObject implements Interface, Runnable, Serializable{	
	private static final long serialVersionUID = 1L;
	//used when having multiple servers
	private ArrayList<String> Servers_URLs;
	//list of clients that this server handles
	private ArrayList<String> Clients_URLs;
	private ArrayList<Integer> Clients_IDs;
	private int Dragon_N;
	public String server_URL;
	private int MinPlayer_N;
	//stats about the Dragon units
	public final int MIN_DHP = 50;
	public final int MAX_DHP = 100;
	public final int MIN_DAP = 5;
	public final int MAX_DAP = 20;
	//machine that contains the server
	private Machine machine;
	private PrintWriter writer;
	
	//constructor of Server
	protected Server(ArrayList<String> Servers_URLs,  int Dragon_N, int MinPlayer_N, Machine machine, String url, String filename) throws RemoteException, FileNotFoundException, UnsupportedEncodingException {
		this.Servers_URLs = new ArrayList<String>(Servers_URLs);
		this.Dragon_N = Dragon_N;
		this.Clients_URLs = new ArrayList<String>();
		this.Clients_IDs = new ArrayList<Integer>();
		this.MinPlayer_N = MinPlayer_N;
		this.machine = machine;
		this.server_URL = url;
		writer = new PrintWriter(filename,"UTF-8");
	}
	
	//runnable
	@Override
	public void run() {
		int HP, AP, x, y, timeout_count;
		String output = null;
		
		Battlefield bf = machine.battlefield;
		
		try {	
			timeout_count = 0;
			//runs while the game isn't over and there hasn't been a timeout
			while(machine.gameStarted == false || (!bf.checkGameOver() && timeout_count < machine.timeout)){
				machine.processStepBuffer();
				
				//prints output into file
				output = machine.getOutput();
				if(output != null)
					writer.println(output);
				
				//starts the game
				if(machine.gameStarted == false && bf.getUnitsNumber() == (Dragon_N+MinPlayer_N))
					machine.addStep(new Command(CommandType.gameStart, 1),null);
				
				//UPDATE
				//spawns the Units
				if(machine.gameStarted == false && bf.getUnitsNumber() < (Dragon_N + MinPlayer_N)){
					//find a free spot
					do{
						x = (int)(Math.random()*bf.getWidth());
						y = (int)(Math.random()*bf.getHeight());
					}while(!bf.posFree(x, y));
					
					if(bf.getUnitsNumber() < Dragon_N){
						HP = (int)(Math.random() * (MAX_DHP - MIN_DHP) + MIN_DHP);
						AP = (int)(Math.random() * (MAX_DAP - MIN_DAP) + MIN_DAP);
						machine.addStep(new Command(CommandType.spawn,HP,HP,AP,x,y,UnitType.dragon,machine.id),null);
					}
				}
				else
					timeout_count++;
				
				Thread.sleep(machine.genActionTs());
			}
			bf.printSurvivingUnits();
			while(output != "END"){
				//prints output into file
				output = machine.getOutput();
				if(output != null && output != "END")
					writer.println(output);
				Thread.sleep(machine.genActionTs());
			}
			writer.close();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	//add new client to list and send a copy of battlefield
	@Override
	public void register(String client_URL, int id) {
		// TODO Auto-generated method stub
		this.Clients_URLs.add(client_URL);
		this.Clients_IDs.add(id);
	 	System.out.println(client_URL + " registered");
	 	writer.println(client_URL + " registered");
		try {
			Interface client = (Interface) java.rmi.Naming.lookup(client_URL);
			client.login(new Command(CommandType.trade,new ArrayList<Unit>(machine.battlefield.getUnits()),machine.id));
		} catch (MalformedURLException | NotBoundException | RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	//implemented on client only
	@Override
	public void login(Command c) {
		
	}
	
	//remove client from list
	@Override
	public synchronized void unregister(String client_URL, int id) {
		// TODO Auto-generated method stub
		this.Clients_URLs.remove(client_URL);
		this.Clients_IDs.remove(Integer.valueOf(id));
	}

	//receive remote event
	@Override
	public synchronized void receiveMessage(Step s) {
		// TODO Auto-generated method stub
		machine.addStep(s.getNormalCommand(),s.getInvCommand());
	}

	//send local event to all clients
	@Override
	public  synchronized void sendMessage(Command normal, Command inverse, int ignore_id) throws RemoteException {
		// TODO Auto-generated method stub
		for (int i=0; i<Clients_URLs.size(); i++){
			if(Clients_IDs.get(i) != ignore_id){
				DelayMessage delay = new DelayMessage(new Step(normal,inverse), Clients_URLs.get(i));
				new Thread(delay).start();
			}
		}
	}
}
