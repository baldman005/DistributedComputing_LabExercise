import java.io.FileNotFoundException;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.rmi.RemoteException;
import java.util.ArrayList;

//class machine that saves either the server or the client
public class Machine implements Serializable{
	private static final long serialVersionUID = 1L;
	private final int MAX_actionTs = 15;
	private final int MIN_actionTs = 5;
	public int id;
	public int timeout = 100000/MIN_actionTs;
	//buffer with commands;
	private ArrayList<Step> steps;
	//curr position in buffer
	private int step_pos = -1;
	private int max_commands = 50;
	public Battlefield battlefield;
	public boolean gameStarted = false;
	//arraylist with the units that the machine will process
	public ArrayList<Unit> my_units;
	//RMI URL of client or server responsible for this machine
	public String owner;
	//buffer with the messages for the file
	public ArrayList<String> outputs;
	private int outputs_pos = -1;
	private int max_outputs = 50;
	//to distinguish ids from servers and clients, saves the number of servers and clients
	public int serversN;
	
	//constructor of Machine
	protected Machine(int id, int MAP_WIDTH, int MAP_HEIGHT, String owner, int serversN) throws RemoteException, FileNotFoundException, UnsupportedEncodingException {
		this.id = id;
		battlefield = new Battlefield(MAP_WIDTH, MAP_HEIGHT,this);
		my_units = new ArrayList<Unit>();
		steps = new ArrayList<Step>();
		this.owner = owner;
		outputs = new ArrayList<String>();
		this.serversN = serversN;
	}
	
	//method to start threads to process units
	public void unitsStart(){
		for(Unit u:my_units)
			u.startProc();
	}
	
	//method to add string to outputs
	public void addOutput(String message){
		if(outputs.size() == max_outputs){
			outputs.remove(0);
			outputs_pos--;
		}
		outputs.add(message);
	}
	
	//method to return an output
	public String getOutput(){
		String out = null;
		
		if((outputs_pos+1) < outputs.size()){
			outputs_pos++;
			out = outputs.get(outputs_pos);
		}
		return out;
	}
	
	//method to process the steps buffer
	public void processStepBuffer(){
		Step s;
		Unit u;
				
		if((step_pos+1) < steps.size()){
			step_pos++;
			s = steps.get(step_pos);
			
			//ATTENTION, POSSIBLE BUG. For some reason, c can rarely come null. For now it ignores
			if(s==null){
				System.out.println(this.owner + ": " +"ERROR, command null");
				this.addOutput("ERROR, command null");
				return;
			}
			u = s.getNormalCommand().processCommand(battlefield, this);
			//means that this server spawned the unit
			if(u != null){
				my_units.add(u);
				//if the game has already begun start processing the unit
				if(gameStarted)
					u.startProc();
			}
		}
	}
	
	//adds step to buffer
	public void addStep(Command normal, Command inverse){
		//if buffer is full discard oldest command
		if(steps.size() == max_commands){
			steps.remove(0);
			step_pos--;
		}
		steps.add(new Step(normal,inverse));
	}
	
	//starts the game
	public void startGame(){
		gameStarted = true;
		unitsStart();
	}
	
	//generate the action delay
	public int genActionTs(){
		return (int)(Math.random() * (MAX_actionTs - MIN_actionTs) + MIN_actionTs);
	}
}