import java.io.Serializable;

public class Step implements Serializable{
	private static final long serialVersionUID = 1L;
	private Command normal;
	private Command inverse;
	
	protected Step(Command normal, Command inverse){
		this.normal = normal;
		this.inverse = inverse;
	}
	
	public Command getNormalCommand(){
		return normal;
	}
	
	public Command getInvCommand(){
		return inverse;
	}
}
