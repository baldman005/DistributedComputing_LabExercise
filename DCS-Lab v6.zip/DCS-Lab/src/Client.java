import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class Client extends UnicastRemoteObject implements Interface, Runnable, Serializable{	
	private static final long serialVersionUID = 1L;
	//URL of the server
	private String server_URL;
	//stats about the Players units
	public final int MIN_PHP = 10;
	public final int MAX_PHP = 20;
	public final int MIN_PAP = 1;
	public final int MAX_PAP = 10;
	//machine that contains the client
	private Machine machine;
	//URL used for registering client to server
	private String client_URL;
    private PrintWriter writer;
	
	//constructor of Server
	protected Client( String server_URL, Machine machine,  String url, String filename) throws RemoteException, FileNotFoundException, UnsupportedEncodingException {
		this.machine = machine;
		this.server_URL = server_URL;
		this.client_URL = url;		
		writer = new PrintWriter(filename,"UTF-8");
	}
	
	//runnable
	@Override
	public void run() {
		int HP, AP, x, y, timeout_count;
		String output = null;
		
		Battlefield bf = machine.battlefield;
		
		
		try {
			Interface server = (Interface) java.rmi.Naming.lookup(server_URL);
			server.register(client_URL,machine.id);
		} catch (MalformedURLException | NotBoundException | RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {	
			timeout_count = 0;
			//runs while the game isn't over and there hasn't been a timeout
			while(machine.gameStarted == false || (!bf.checkGameOver() && timeout_count < machine.timeout)){
				machine.processStepBuffer();
				
				//prints output into file
				output = machine.getOutput();
				if(output != null)
					writer.println(output);
				
				//UPDATE
				//spawns the Units
				if(!machine.gameStarted && machine.my_units.size() < 1){		
					do{
						x = (int)(Math.random()*bf.getWidth());
						y = (int)(Math.random()*bf.getHeight());
					}while(!bf.posFree(x, y));
					
					HP = (int)(Math.random() * (MAX_PHP - MIN_PHP) + MIN_PHP);
					AP = (int)(Math.random() * (MAX_PAP - MIN_PAP) + MIN_PAP);
					machine.addStep(new Command(CommandType.spawn,HP,HP,AP,x,y,UnitType.player,machine.id),null);
					sendMessage(new Command(CommandType.spawn,HP,HP,AP,x,y,UnitType.player,machine.id),null,-1);
				}
				else
					timeout_count++;
				
				Thread.sleep(machine.genActionTs());
			}
			bf.printSurvivingUnits();
			while(output != "END"){
				//prints output into file
				output = machine.getOutput();
				if(output != null && output != "END")
					writer.println(output);
				Thread.sleep(machine.genActionTs());
			}
			writer.close();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	//send local event to server
	@Override
	public synchronized void sendMessage(Command normal, Command inverse, int ignore_id) {
		DelayMessage delay = new DelayMessage(new Step(normal,inverse), server_URL);
		new Thread(delay).start();
	}
	
	//receive remote event from server
	@Override
	public void receiveMessage(Step s) throws RemoteException {
		// TODO Auto-generated method stub
		machine.addStep(s.getNormalCommand(), s.getInvCommand());
	}

	
	//implemented in server only
	@Override
	public void register(String url, int id) throws RemoteException {
		// TODO Auto-generated method stub
		
	}

	//implemented in server only
	@Override
	public void unregister(String url, int id) throws RemoteException {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public synchronized void login(Command c) throws RemoteException {
		System.out.println(client_URL + " logged on");
		writer.println(client_URL + " logged on");
		machine.battlefield.setUnits(c.getUnits(), c.arg(0));
	}
}
