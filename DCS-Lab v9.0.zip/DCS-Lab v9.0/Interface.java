import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

//Interface that enables processes to communicate
public interface Interface extends Remote {
	public void receiveMessage(PhaseType type, Step s, boolean toCommit) throws RemoteException;

	public void register(String url, int id) throws RemoteException;

	public void unregister(String url, int id) throws RemoteException;

	public void sendMessage(PhaseType type, Step s, boolean toCommit, int receiver_id, boolean toServer) throws RemoteException;
	
	public void login(ArrayList<Unit> units, int id, int timestamp, int ts) throws RemoteException;
}
