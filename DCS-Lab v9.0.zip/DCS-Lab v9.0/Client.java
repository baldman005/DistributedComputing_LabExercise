import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Timestamp;
import java.util.ArrayList;

public class Client extends UnicastRemoteObject implements Interface, Runnable, Serializable{	
	private static final long serialVersionUID = 1L;
	//URL of the server
	private ArrayList<String> Servers_URLs;
	//machine that contains the client
	private Machine machine;
	//URL used for registering client to server
	private String client_URL;
    private PrintWriter writer;
	
	//constructor of Server
	protected Client( ArrayList<String> Servers_URLs, Machine machine,  String url, String filename) throws RemoteException, FileNotFoundException, UnsupportedEncodingException {
		this.machine = machine;
		this.Servers_URLs = new ArrayList<String>(Servers_URLs);
		this.client_URL = url;		
		writer = new PrintWriter(filename,"UTF-8");
	}
	
	//runnable
	@Override
	public void run() {
		int timeout_count, overCount;
		String output = null;
		Battlefield bf = machine.battlefield;
		
		try {
			Interface server = (Interface) java.rmi.Naming.lookup(Servers_URLs.get(machine.host_id));
			server.register(client_URL,machine.id);
		} catch (MalformedURLException | NotBoundException | RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {	
			timeout_count = 0;
			overCount = 0;
			//runs while the game isn't over and there hasn't been a timeout
			while(machine.gameStarted == false || (timeout_count < machine.timeout && !bf.checkGameOver()) || (overCount < machine.gameOverCount && bf.checkGameOver())){
				machine.processStepBuffer();
								
				//prints output into file
				output = machine.getOutput();
				if(output != null)
					writer.println(output);
				
				Thread.sleep(machine.genActionTs());
				//waits if game appears to end to check if it's necessary to do a rollback
				if(bf.checkGameOver() && machine.gameStarted){
					overCount++;
					if(timeout_count>0)
						timeout_count--;
				}else if(overCount != 0){
					overCount = 0;
				}
				if(timeout_count == machine.timeout)
					System.out.println("DEBUG TIME");
			}
			bf.printSurvivingUnits();
			while(output != "END"){
				//prints output into file
				output = machine.getOutput();
				if(output != null && output != "END")
					writer.println(output);
				Thread.sleep(machine.genActionTs());
			}
			writer.close();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	//send local event to server
	@Override
	public void sendMessage(PhaseType type, Step s, boolean toCommit, int receiver_id, boolean toServer) {
		new Thread(new DelayMessage(type, s, toCommit, Servers_URLs.get(receiver_id))).start();
	}
	
	//receive remote event from server
	@Override
	public synchronized void receiveMessage(PhaseType type, Step s, boolean toCommit) throws RemoteException {
		machine.val_buffer.addCommit(type, new Step(s), toCommit);
	}

	
	//implemented in server only
	@Override
	public void register(String url, int id) throws RemoteException {
		// TODO Auto-generated method stub
		
	}

	//implemented in server only
	@Override
	public void unregister(String url, int id) throws RemoteException {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void login(ArrayList<Unit> units, int id, int timestamp, int ts) throws RemoteException{
		System.out.println(client_URL + " logged on");
		writer.println(client_URL + " logged on");
		//get time from server in the beginning
		machine.setTimeDiff(ts);
		machine.setTimestamp(timestamp);
		machine.battlefield.setUnits(units, id);
	}
}
