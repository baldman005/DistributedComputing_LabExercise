import java.io.Serializable;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;

//class that deals with the 2 phase variables and methods
public class FaultTol implements Serializable{
	private static final long serialVersionUID = 1L;

	//Commit is a variable that needs to be committed (or aborted) and then goes to machine's steps
	public class Commit implements Serializable{
		private static final long serialVersionUID = 1L;

		public Step step;
		public int commit = 0, abort = 0;
		public int timecount = 0;
		
		//constructor for Commit
		protected Commit(Step step){
			this.step = step;
		}
	}
	
	private Machine machine;
	private ArrayList<Commit> commits; 
	//number of faulty servers
	private int f = 0;
	//count that means the host has died
	private int timecount_death;
	//max size of the buffer
	private int max_size = 100;
	
	//constructor of FaultTol
	protected FaultTol(Machine machine){
		this.machine = machine;
		commits = new ArrayList<Commit>();
		timecount_death = 2*6000/(machine.MIN_actionTs + machine.MAX_actionTs);
	}
	
	//check if it's a valid command or not
	private boolean checkValidity(Command c){
		return true;
	}
	
	//method to see if there is already a commit (only increments counts) or add new one
	private synchronized int processCommit(Step s, boolean newCommit, boolean toCommit){
		for(Commit c:commits){
			if(c.step.getOriginId() == s.getOriginId() && c.step.getTimestamp() == s.getTimestamp() && s.getNormalCommand().sameAs(c.step.getNormalCommand())){
				if(newCommit){
					//System.out.println("ERROR: already exists1");
					return -1;
				}
				else if(!newCommit && toCommit){
					c.commit++;
					return c.commit;
				}
				else{
					c.abort++;
					return c.abort;
				}
			}
		}
		
		//buffer is full, so remove old messages
		if(commits.size() == max_size)
			commits.remove(0);
		
		//Step doesn't exist yet in list, so add it
		Commit c = new Commit(new Step(s));
		commits.add(c);
			
		if((newCommit && checkValidity(s.getNormalCommand())) || (!newCommit && toCommit)){
			c.commit++;
			return c.commit;
		}
		c.abort++;
		return c.abort;
	}
	
	//when receiving a commit chooses how to proceed
	public synchronized void addCommit(PhaseType type, Step s, boolean toCommit) {
		//case of being a server
		if(machine.id < machine.serversN){
			//is the host
			if(machine.id == machine.host_id){
				switch(type){
					case request:
						//add commit (should be new, so check that) and send prepare to replicas
						if(processCommit(s,true,false) != 1){
							//System.out.println("ERROR: already existed");
							break;
						}
						//if there are no faulty nodes then is ready to send reply 
						else if(f == 0){
							machine.sendToAllClients(PhaseType.reply, s, checkValidity(s.getNormalCommand()));
							commitDone(s);
							/*done = commitDone(s);
							if(done != null)
								commits.remove(done);*/
							//send to all clients reply
						}
						machine.sendToOtherServers(PhaseType.commit, s, checkValidity(s.getNormalCommand()), machine.id);
						break;
					case commit:
						//increment count and if equal to 2f+1 send to client (if abort) or all clients (if commit)
						if(processCommit(s,false,toCommit) == 2*f + 1){
							commitDone(s);
							machine.sendToAllClients(PhaseType.reply, s, checkValidity(s.getNormalCommand()));
						}
						
						break;
					default:
						break;
				}
			}else{
				switch(type){
					case request:
						//add commit, elect new host, send prepare to replicas 
						//UPDATE WHEN SIMULATING CRASHES
						break;
					case commit:
						//increment count and if equal to 2f+1 send to client (if abort) or all clients (if commit)
						if(processCommit(s,false,toCommit) == 2*f + 1){
							//send to all clients
							commitDone(s);
							/*done = commitDone(s);
							if(done != null)
								commits.remove(done);*/
							//send to all clients reply
							machine.sendToAllClients(PhaseType.reply, s, checkValidity(s.getNormalCommand()));
						}
						break;
					case prepare:
						//send to all servers a commit
						//machine.sendToOtherServers(PhaseType.commit, s, checkValidity(s.getNormalCommand()), machine.id);
						machine.sendToOtherServers(PhaseType.commit, s, checkValidity(s.getNormalCommand()), machine.id);
						
						//there can be a big delay in sending prepare and replica receives all commits first, so check here also
						if(processCommit(s,true,false) == 2*f + 1){
							//send to all clients
							commitDone(s);
							/*done = commitDone(s);
							if(done != null)
								commits.remove(done);*/
							//send to all clients reply
							machine.sendToAllClients(PhaseType.reply, s, checkValidity(s.getNormalCommand()));
						}
						break;
					default:
						break;
				}
			}
		}else{
			switch(type){
				case reply:
					//increment count and if equal to f+1 it has received all replies necessary
					if(processCommit(s,false,toCommit) == f + 1){
						commitDone(s);
						/*done = commitDone(s);
						if(done != null)
							commits.remove(done);*/
						//send to all clients reply
					}
					break;
				default:
					break;
			}
		}
	}


	//When commit is ready to leave, see if it is to be processed or aborted
	private synchronized Commit commitDone(Step s){
		for(Commit c:commits){
			if(c.step.getOriginId() == s.getOriginId() && c.step.getTimestamp() == s.getTimestamp() && s.getNormalCommand().sameAs(c.step.getNormalCommand())){
				//means it is to be committed
				if(c.commit > c.abort){
					machine.addStep(s.getNormalCommand(), s.getInvCommand(), s.getTimestamp());
					return c;
				}
			}
		}
		return null;
	}
	
	//Check if the buffer has a spawn created by this machine
	public synchronized boolean hasMyCommand(CommandType type){
		for(Commit c:commits){
			if(c.step.getOriginId() == machine.id && c.step.getNormalCommand().getType() == type){
				return true;
			}
		}
		return false;
	}
		
	//Return number of spawns in this buffer
	public synchronized int myCommandNum(CommandType type){
		int count = 0;
		for(Commit c:commits){
			if(c.step.getOriginId() == machine.id && c.step.getNormalCommand().getType() == type){
				count++;
			}
		}
		return count;
	}
	
	//Prints the Commits buffer
	public void printCommit(){
		for (Commit c:commits){
			System.out.println("ORIGIN ID " + c.step.getOriginId());
			System.out.println("TIMESTAMP " + c.step.getTimestamp());
			System.out.println("COMMAND TYPE " + c.step.getNormalCommand().getType());
			System.out.println("COMMITS " + c.commit);
			System.out.println("ABORTS " + c.abort);
			System.out.println("_____________________________");
		}
	}
}