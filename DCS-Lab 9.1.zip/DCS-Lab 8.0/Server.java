import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

//class Server
public class Server extends UnicastRemoteObject implements Interface, Runnable, Serializable{	
	private static final long serialVersionUID = 1L;
	//used when having multiple servers
	private ArrayList<String> Servers_URLs;
	//list of clients that this server handles
	private ArrayList<String> Clients_URLs;
	private ArrayList<Integer> Clients_IDs;
	private int Dragon_N;
	public String server_URL;
	private int MinPlayer_N;
	//stats about the Dragon units
	public final int MIN_DHP = 50;
	public final int MAX_DHP = 100;
	public final int MIN_DAP = 5;
	public final int MAX_DAP = 20;
	//machine that contains the server
	private Machine machine;
	private PrintWriter writer;
	//stats about the Players units
	public final int MIN_PHP = 10;
	public final int MAX_PHP = 20;
	public final int MIN_PAP = 1;
	public final int MAX_PAP = 10;
	private boolean crashed;
	
	//constructor of Server
	protected Server(ArrayList<String> Servers_URLs,  int Dragon_N, int MinPlayer_N, Machine machine, String url, String filename) throws RemoteException, FileNotFoundException, UnsupportedEncodingException {
		this.Servers_URLs = new ArrayList<String>(Servers_URLs);
		this.Dragon_N = Dragon_N;
		this.Clients_URLs = new ArrayList<String>();
		this.Clients_IDs = new ArrayList<Integer>();
		this.MinPlayer_N = MinPlayer_N;
		this.machine = machine;
		this.server_URL = url;
		writer = new PrintWriter(filename,"UTF-8");
		machine.setTimeDiff(1);
		this.crashed = false;
	}
	
	//runnable
	@Override
	public void run() {
		int HP, AP, x, y, timeout_count, overCount;
		String output = null;
		
		Battlefield bf = machine.battlefield;
		
		try {	
			timeout_count = 0;
			overCount = 0;
			//runs while the game isn't over and there hasn't been a timeout
			while(machine.gameStarted == false || (timeout_count < machine.timeout && !bf.checkGameOver()) || (overCount < machine.gameOverCount && bf.checkGameOver())){
				if (!this.crashed) {
					machine.processStepBuffer();
					
					//prints output into file
					output = machine.getOutput();
					if(output != null)
						writer.println(output);
					
					if(machine.id == machine.host_id){
						if(!machine.gameStarted && bf.getUnitsNumber() >= (Dragon_N+MinPlayer_N) && machine.finalRollPos == -1 && !machine.val_buffer.hasMyCommand(CommandType.gameStart)){
							machine.val_buffer.addCommit(PhaseType.request, new Step(new Command(CommandType.gameStart, machine.id),new Command(CommandType.falseStart, machine.id),machine.timestamp),false);
						}
	
						//UPDATE
						//spawns the Units
						if(!machine.gameStarted && bf.getUnitsNumber() < (Dragon_N + MinPlayer_N)){						
							if(machine.val_buffer.myCommandNum(CommandType.spawn) < Dragon_N && machine.finalRollPos == -1){
								//find a free spot
								do{
									x = (int)(Math.random()*bf.getWidth());
									y = (int)(Math.random()*bf.getHeight());
								}while(!bf.posFree(x, y));
								
								HP = (int)(Math.random() * (MAX_DHP - MIN_DHP) + MIN_DHP);
								AP = (int)(Math.random() * (MAX_DAP - MIN_DAP) + MIN_DAP);
								
								machine.val_buffer.addCommit(PhaseType.request, new Step(new Command(CommandType.spawn,HP,HP,AP,x,y,UnitType.dragon, bf.getCurrID(),machine.id),new Command(CommandType.remove,x,y,machine.id),machine.timestamp),false);
							}
						}
						else
							timeout_count++;
					} else if(machine.gameStarted)
						timeout_count++;
					
					Thread.sleep(machine.genActionTs());
	
					//waits if game appears to end to check if it's necessary to do a rollback
					if(bf.checkGameOver() && machine.gameStarted){
						overCount++;
						if(timeout_count>0)
							timeout_count--;
					}else if(overCount != 0){
						overCount = 0;
					}
					
					if(timeout_count == machine.timeout)
						System.out.println("DEBUG TIME");
				}
			}
			bf.printSurvivingUnits();
			while(output != "END"){
				//prints output into file
				output = machine.getOutput();
				if(output != null && output != "END")
					writer.println(output);
				Thread.sleep(5);
			}
			writer.close();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	//add new client to list and send a copy of battlefield
	@Override
	public synchronized void register(String client_URL, int id) {
		int x,y,HP,AP;
		Battlefield bf = machine.battlefield;
		
		this.Clients_URLs.add(client_URL);
		this.Clients_IDs.add(id);
	 	System.out.println(client_URL + " registered");
	 	writer.println(client_URL + " registered");
	 	
	 	if(machine.id != machine.host_id)
	 		return;
	 	
	 	
	 	//only host does this
		try {
			//register for other clients
			for(int i = 0; i < Servers_URLs.size(); i++){
				if(i == machine.id)
					continue;
				Interface replica = (Interface) java.rmi.Naming.lookup(Servers_URLs.get(i));
				replica.register(client_URL, id);
			}
			
			Interface client = (Interface) java.rmi.Naming.lookup(client_URL);
			client.login(new ArrayList<Unit>(machine.battlefield.getUnits()),machine.id,machine.timestamp,machine.ts);
		} catch (MalformedURLException | NotBoundException | RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		//try to spawn the player
		//find a free spot
		do{
			x = (int)(Math.random()*bf.getWidth());
			y = (int)(Math.random()*bf.getHeight());
		}while(!bf.posFree(x, y));
		
		HP = (int)(Math.random() * (MAX_PHP - MIN_PHP) + MIN_PHP);
		AP = (int)(Math.random() * (MAX_PAP - MIN_PAP) + MIN_PAP);

		machine.val_buffer.addCommit(PhaseType.request, new Step(new Command(CommandType.spawn,HP,HP,AP,x,y,UnitType.player, bf.getCurrID(),id),new Command(CommandType.remove,x,y,id),machine.timestamp),false);
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	//implemented on client only
	@Override
	public void login(ArrayList<Unit> units, int id, int timestamp, int ts){
		
	}
	
	//remove client from list
	@Override
	public void unregister(String client_URL, int id) {
		// TODO Auto-generated method stub
		this.Clients_URLs.remove(client_URL);
		this.Clients_IDs.remove(Integer.valueOf(id));
	}

	//receive remote event
	@Override
	public synchronized void receiveMessage(PhaseType type, Step s, boolean toCommit) {
		machine.val_buffer.addCommit(type, new Step(s), toCommit);
	}

	//send local event to machine
	@Override
	public void sendMessage(PhaseType type, Step s, boolean toCommit, int receiver_id, boolean toServer) {
		if(toServer){
			new Thread(new DelayMessage(type, s, toCommit, Servers_URLs.get(receiver_id))).start();
		}else{
			//send to all clients
			for(int i = 0; i < Clients_URLs.size(); i++){
				new Thread(new DelayMessage(type, s, toCommit, Clients_URLs.get(i))).start();
			}
		}
	}
	
	@Override
	public void crash() {
		this.crashed = true;
	} 
	
	@Override
	public boolean isCrashed() {
		return this.crashed;
	}
	
	@Override
	public boolean isGameOver() {
		return this.machine.battlefield.checkGameOver();
	}

	@Override
	public void restart() {
		this.crashed = false;
	}
	
	@Override
	public ArrayList<Unit> getBattlefield() {
		return new ArrayList<Unit>(machine.battlefield.getUnits());
	}
}
