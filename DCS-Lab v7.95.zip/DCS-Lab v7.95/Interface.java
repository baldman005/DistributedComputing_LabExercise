import java.rmi.Remote;
import java.rmi.RemoteException;

//Interface that enables processes to communicate
public interface Interface extends Remote {
	public void receiveMessage(Step s) throws RemoteException;

	public void register(String url, int id) throws RemoteException;

	public void unregister(String url, int id) throws RemoteException;

	public void sendMessage(Command nor, Command inv, int ignore_id, int timestamp) throws RemoteException;
	
	public void login(Command c, int timestamp, int ts) throws RemoteException;
}
