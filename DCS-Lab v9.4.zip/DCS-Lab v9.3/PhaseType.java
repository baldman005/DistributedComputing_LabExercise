public enum PhaseType{
	request, prepare, commit, reply, mine, elect
}
