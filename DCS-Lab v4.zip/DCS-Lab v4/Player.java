//Class that has runnable that processes Player Unit
public class Player implements Runnable{
	//Player unit
	private Unit unit;
	//Battlefield
	private static Battlefield bf;
	//Delay between actions
	private static final int MIN_actionTs = 200;
	private static final int MAX_actionTs = 300;
	//Attack range
	private static final int attackDist = 2;
	//Heal range
	private static final int healDist = 5;
	
	//Constructor
	public Player(Unit unit, Battlefield bf){
		this.unit = unit;
		Player.bf = bf;
	}
	
	//tries to heal a close wounded ally; returns true if success, false otherwise
	private boolean healWoundedAlly(){
		Unit ally;
		
		ally = bf.getNearestUnitType(unit,UnitType.player);
		if(ally != null && unit.calcDist(ally) <= healDist && ally.getRemHP() <= 50){
			bf.getMachine().addCommand(new Command(CommandType.heal,unit,ally));
			return true;
		}
		return false;
	}
	
	//moves to a dragon
	//if there is an obstacle in the way just stays in the same place
	private synchronized void moveToDragon(Unit dragon){
		int disX, disY, vX, vY;
		
		disX = dragon.getX() - unit.getX();
		disY = dragon.getY() - unit.getY();
		vX = Integer.signum(disX);
		vY = Integer.signum(disY);
		
		if(Math.abs(disX) == Math.abs(disY)){
			if(bf.posFree(unit.getX(), unit.getY()+vY))
				bf.getMachine().addCommand(new Command(CommandType.move,unit,0,vY));
			else
				bf.getMachine().addCommand(new Command(CommandType.move,unit,vX,0));
		}
		else if(Math.abs(disX) > Math.abs(disY))
			bf.getMachine().addCommand(new Command(CommandType.move,unit,vX,0));
		else{
			bf.getMachine().addCommand(new Command(CommandType.move,unit,0,vY));
		}
	}
	
	//tries to attack a close dragon; if not possible, moves to the closest one
	private void attackOrMoveToDragon(){
		Unit dragon;
		
		dragon = bf.getNearestUnitType(unit,UnitType.dragon);
		if(dragon != null){
			if(unit.calcDist(dragon) <= attackDist)
				bf.getMachine().addCommand(new Command(CommandType.attack,unit,dragon));
			else
				moveToDragon(dragon);
		}
	}
	
	//runnable
	@Override
	public void run() {				
		try{
		while(unit.checkRunning()){
			//tries to heal ally
			if(!healWoundedAlly())
				//attacks or moves to a dragon
				attackOrMoveToDragon();
			Thread.sleep((int)(Math.random() * (MAX_actionTs - MIN_actionTs) + MIN_actionTs));
		}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}