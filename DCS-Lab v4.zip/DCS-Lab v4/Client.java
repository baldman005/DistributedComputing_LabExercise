import java.io.UnsupportedEncodingException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

//class Client
public class Client extends UnicastRemoteObject implements Runnable {
	private static final long serialVersionUID = 1L;
	
	private String Server_URL;
	//stats about the Players units
	public final int MIN_PHP = 10;
	public final int MAX_PHP = 20;
	public final int MIN_PAP = 1;
	public final int MAX_PAP = 10;
	//machine that contains the client
	private Machine machine;
	
	//constructor of Client
	protected Client(String Server_URL, Machine machine) throws RemoteException, UnsupportedEncodingException {
		this.Server_URL = Server_URL;
		this.machine = machine;
	}
	
	//runnable
	@Override
	public synchronized void run() {
		int HP, AP, x, y, timeout_count;
		Battlefield bf = machine.battlefield;
		
		//battlefield save machine
		
		try {	
			timeout_count = 0;
			//runs while the game isn't over and there hasn't been a timeout
			while(machine.gameStarted == false || (!bf.checkGameOver() && timeout_count < machine.timeout)){
				machine.processComBuffer();
				
				//UPDATE
				//spawns the Units
				if(!machine.gameStarted && machine.my_units.size() == 0){
					//find a free spot
					do{
						x = (int)(Math.random()*bf.getWidth());
						y = (int)(Math.random()*bf.getHeight());
					}while(!bf.posFree(x, y));
					
					HP = (int)(Math.random() * (MAX_PHP - MIN_PHP) + MIN_PHP);
					AP = (int)(Math.random() * (MAX_PAP - MIN_PAP) + MIN_PAP);
					machine.addCommand(new Command(CommandType.spawn,HP,HP,AP,x,y,UnitType.player,machine.id));
				}
				else
					timeout_count++;
				
				Thread.sleep(machine.genActionTs());
			}
			bf.printSurvivingUnits();
			machine.writer.close();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
