// Unit Type
public enum UnitType {
	player, dragon,
};
