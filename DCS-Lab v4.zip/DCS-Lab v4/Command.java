import java.util.ArrayList;

public class Command {
	private CommandType type;
	private ArrayList<Integer> args_int;
	private ArrayList<Unit> args_unit;
	
	//constructor for gameStart
	public Command(CommandType type){
		this.type = type;
	}
	
	//constructor with unit to be removed (for remove)
	public Command(CommandType type, Unit source){
		this.type = type;
		args_unit = new ArrayList<Unit>();
		args_unit.add(source);
	}
	
	//constructor 1 value of coordinates, currHP, maxHP, AP, the unit type (0 dragon, 1 player)(for spawn), and the id of the client/server
	public Command(CommandType type, int currHP, int maxHP, int AP, int x, int y, UnitType unittype, int sender_id){
		this.type = type;
		args_int = new ArrayList<Integer>();
		args_int.add(currHP);
		args_int.add(maxHP);
		args_int.add(AP);
		args_int.add(x);
		args_int.add(y);
		switch(unittype){
			case dragon:
				args_int.add(0);
				break;
			case player:
				args_int.add(1);
				break;
		}
		args_int.add(sender_id);
	}
	
	//constructor with only 2 values of coordinates(for attack or heal)
	public Command(CommandType type, Unit source, Unit target){
		this.type = type;
		args_unit = new ArrayList<Unit>();
		args_unit.add(source);
		args_unit.add(target);
	}
	
	//constructor with unit to be moved (for move)
	public Command(CommandType type, Unit source, int x, int y){
		this.type = type;
		args_unit = new ArrayList<Unit>();
		args_unit.add(source);
		args_int = new ArrayList<Integer>();
		args_int.add(x);
		args_int.add(y);
	}
	
	//return command type
	public CommandType getType(){
		return type;
	}
	
	//return integer argument i
	public int arg(int i){
		if (i < args_int.size())
			return args_int.get(i);
		return -1;
	}
	
	//return unit source
	public Unit getSource(){
		return args_unit.get(0);
	}
	
	//return unit source
	public Unit getTarget(){
		return args_unit.get(1);
	}
	
	//method to process a command
	public Unit processCommand(Battlefield battlefield, int id, Machine machine){
		Unit new_unit = null;
		
		switch(this.getType()){
			case spawn:
				UnitType unittype;
				if(this.arg(5)==1)
					unittype = UnitType.player;
				else
					unittype = UnitType.dragon;
				
				new_unit = new Unit(this.arg(0),this.arg(1),this.arg(2),this.arg(3),this.arg(4),battlefield.getCurrID(),unittype,battlefield);
				battlefield.spawnUnit(new_unit);
				if(id != this.arg(6))
					new_unit = null;
				break;
			case remove:
				battlefield.removeUnit(this.getSource());
				break;
			case attack:
				if(this.getSource().checkRunning())
					this.getSource().attackUnit(this.getTarget());
				break;
			case heal:
				if(this.getSource().checkRunning())
					this.getSource().healUnit(this.getTarget());
				break;
			case move:
				this.getSource().moveUnit(this.arg(0),this.arg(1));
				break;
			case gameStart:
				machine.startGame();
				break;
			default:
				break;
		}
		return new_unit;
	}
}
