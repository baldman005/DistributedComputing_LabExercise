import java.util.ArrayList;

//class that contains the battlefield
public class Battlefield {
	private static int MAP_WIDTH, MAP_HEIGHT;
	private Unit[][] map;
	private ArrayList<Unit> units;
	// ID of next unit that spawns
	private int currID;
	//boolean to known whether the game has ended or not
	private boolean gameOver = false;
	//machine(server/client) connected to battlefield 
	private Machine machine;
	
	//constructor
	protected Battlefield(int width, int height, Machine machine) {		
		map = new Unit[width][height];
		units = new ArrayList<Unit>();
		currID = 0;
		MAP_WIDTH = width;
		MAP_HEIGHT = height;
		this.machine = machine;
	}
	
	//return machine
	public Machine getMachine(){
		return machine;
	}
	
	//spawns a unit in the battlefield
	public synchronized boolean spawnUnit(Unit unit){
		if(map[unit.getX()][unit.getY()] == null){
			System.out.println(unit.getType() + " "+ unit.getUnitID() + " has SPAWNED in position (" + unit.getX() + "," + unit.getY()+"); HP: "+unit.getHP()+" AP: "+unit.getAP());
			machine.writeFile(unit.getType() + " "+ unit.getUnitID() + " has SPAWNED in position (" + unit.getX() + "," + unit.getY()+"); HP: "+unit.getHP()+" AP: "+unit.getAP());
			
			map[unit.getX()][unit.getY()] = unit;
			units.add(unit);
			//update current id
			if(unit.getUnitID() >=  currID){
				currID = unit.getUnitID()+1;
			}
			
			return true;
		}
		else
			return false;
	}
	
	//check if a faction won or if there has been a draw. If yes then return true
	public synchronized boolean VicOrDraw(){
		if(units.size() < 2)
			return true;
		for(int i=1; i<units.size(); i++)
			if(units.get(i-1).getType() != units.get(i).getType())
				return false;
		return true;
	}
	
	//removes a unit from the battlefield
	public synchronized void removeUnit(Unit unit){
		map[unit.getX()][unit.getY()] = null;
		units.remove(unit);

		System.out.println(unit.getType() + " "+ unit.getUnitID() + " has been REMOVED");
		machine.writeFile(unit.getType() + " "+ unit.getUnitID() + " has been REMOVED");
		
		if(VicOrDraw())
			gameOver = true;
	}
	
	//finds nearest unit of type UnitType in battlefield
	public synchronized Unit getNearestUnitType(Unit source, UnitType type){
		int dist, minDist = 10000; //initial minimum distance found is infinite
		Unit closest = null;
		
		for(Unit u:units){
			if(u.getType()!=type)
				continue;
			
			dist = source.calcDist(u);
			//u is equal to source unit
			if(dist == 0)
				continue;
			else if(dist < minDist){
				minDist = dist;
				closest = u;
			}
		}
		return closest;
	}
	
	//moves unit in the battlefield
	public synchronized void moveUnitBf(int old_x, int old_y, int new_x, int new_y){
		map[new_x][new_y] = map[old_x][old_y];
		map[old_x][old_y] = null;
	}
	
	//returns MAP_WIDTH
	public int getWidth(){
		return MAP_WIDTH;
	}
	
	//returns MAP_HEIGHT
	public int getHeight(){
		return MAP_HEIGHT;
	}
	
	//returns unit at position (x,y)
	public synchronized Unit getUnit(int x, int y){
		return map[x][y];
	}
	
	//return the currID
	public synchronized int getCurrID(){
		return currID;
	}
	
	//returns the boolean gameOver
	public boolean checkGameOver(){
		return gameOver;
	}
	
	//returns the number of units
	public int getUnitsNumber(){
		return units.size();
	}
	
	//checks if position is occupied or not
	public synchronized boolean posFree(int x,int y){
		if(map[x][y] == null)
			return true;
		return false;
	}
	
	//method to print the surviving units
	public void printSurvivingUnits(){
		System.out.println("GAME OVER");
		machine.writeFile("GAME OVER");
		if(units.size() == 0){
			System.out.println("DRAW, revenge has consumed them ");
			machine.writeFile("DRAW, revenge has consumed them ");
		}
		else if(VicOrDraw())
			if(units.get(0).getType() == UnitType.dragon){
				System.out.println("DRAGONS continue to rule the Silence Fields");
				machine.writeFile("DRAGONS continue to rule the Silence Fields");;
			}
			else{
				System.out.println("KNIGHTS have brought justice to the Silence Fields");
				machine.writeFile("KNIGHTS have brought justice to the Silence Fields");
			}
		else{
			System.out.println("TIMEOUT");
			machine.writeFile("TIMEOUT");
		}
		System.out.println("Surviving units:");
		machine.writeFile("Surviving units:");
		for(Unit u:units){
			System.out.println(u.getType()+" unit "+u.getUnitID()+"; pos: ("+u.getX()+","+u.getY()+"); HP: "+u.getHP()+"("+u.getRemHP()+"%)");
			machine.writeFile(u.getType()+" unit "+u.getUnitID()+"; pos: ("+u.getX()+","+u.getY()+"); HP: "+u.getHP()+"("+u.getRemHP()+"%)");
		}
	}
}
