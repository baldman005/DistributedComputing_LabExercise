import java.io.UnsupportedEncodingException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

//class Server
public class Server extends UnicastRemoteObject implements Runnable {
	private static final long serialVersionUID = 1L;
	
	private ArrayList<String> Servers_URLs;
	private ArrayList<String> Clients_URLs;
	private int Dragon_N;
	private int MaxPlayer_N;
	//stats about the Dragon units
	public final int MIN_DHP = 50;
	public final int MAX_DHP = 100;
	public final int MIN_DAP = 5;
	public final int MAX_DAP = 20;
	//stats about the Players units TO BE REMOVED LATER (Servers don't spawn the players)
	public final int MIN_PHP = 10;
	public final int MAX_PHP = 20;
	public final int MIN_PAP = 1;
	public final int MAX_PAP = 10;
	//machine that contains the server
	private Machine machine;
	
	//constructor of Server
	protected Server(ArrayList<String> Servers_URLs, int Dragon_N, int MaxPlayer_N, Machine machine) throws RemoteException, UnsupportedEncodingException{
		this.Servers_URLs = Servers_URLs;
		Clients_URLs = new ArrayList<String>();
		this.Dragon_N = Dragon_N;
		this.MaxPlayer_N = MaxPlayer_N;
		this.machine = machine;
	}
	
	//runnable
	@Override
	public synchronized void run() {
		int HP, AP, x, y, timeout_count;
		Battlefield bf = machine.battlefield;
		
		//battlefield save machine
		
		try {	
			timeout_count = 0;
			//runs while the game isn't over and there hasn't been a timeout
			while(machine.gameStarted == false || (!bf.checkGameOver() && timeout_count < machine.timeout)){
				machine.processComBuffer();
				
				//starts the game
				if(machine.gameStarted == false && bf.getUnitsNumber() == (Dragon_N+MaxPlayer_N))
					machine.addCommand(new Command(CommandType.gameStart));
				
				//UPDATE
				//spawns the Units
				if(machine.gameStarted == false && bf.getUnitsNumber() < (Dragon_N + MaxPlayer_N)){
					//find a free spot
					do{
						x = (int)(Math.random()*bf.getWidth());
						y = (int)(Math.random()*bf.getHeight());
					}while(!bf.posFree(x, y));
					
					if(bf.getUnitsNumber() < Dragon_N){
						HP = (int)(Math.random() * (MAX_DHP - MIN_DHP) + MIN_DHP);
						AP = (int)(Math.random() * (MAX_DAP - MIN_DAP) + MIN_DAP);
						machine.addCommand(new Command(CommandType.spawn,HP,HP,AP,x,y,UnitType.dragon,machine.id));
					}
					else{
						HP = (int)(Math.random() * (MAX_PHP - MIN_PHP) + MIN_PHP);
						AP = (int)(Math.random() * (MAX_PAP - MIN_PAP) + MIN_PAP);
						machine.addCommand(new Command(CommandType.spawn,HP,HP,AP,x,y,UnitType.player,machine.id));
					}
				}
				else
					timeout_count++;
				
				Thread.sleep(machine.genActionTs());
			}
			bf.printSurvivingUnits();
			machine.writer.close();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
