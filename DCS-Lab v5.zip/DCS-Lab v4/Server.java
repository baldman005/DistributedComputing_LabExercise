import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

//class Server
public class Server extends UnicastRemoteObject implements Interface, Runnable {
	private static final long serialVersionUID = 1L;
	
	//used when having multiple servers
	private ArrayList<String> Servers_URLs;
	//list of clients that this server handles
	private ArrayList<String> Clients_URLs;
	private int Dragon_N;
	public String server_URL;
	private int MaxPlayer_N;
	//stats about the Dragon units
	public final int MIN_DHP = 50;
	public final int MAX_DHP = 100;
	public final int MIN_DAP = 5;
	public final int MAX_DAP = 20;
	//machine that contains the server
	private Machine machine;
	
	//constructor of Server
	protected Server(ArrayList<String> Servers_URLs,  int Dragon_N, int MaxPlayer_N, Machine machine, String url) throws RemoteException, FileNotFoundException, UnsupportedEncodingException {
		this.Servers_URLs = new ArrayList<String>(Servers_URLs);
		this.Dragon_N = Dragon_N;
		this.Clients_URLs = new ArrayList<String>();
		this.MaxPlayer_N = MaxPlayer_N;
		this.machine = machine;
		this.server_URL = url;
	}

	
	//runnable
	@Override
	public void run() {
		int HP, AP, x, y, timeout_count;
		//battlefield save machine
		Battlefield bf = machine.battlefield;
		
		
		
		try {	
			timeout_count = 0;
			//runs while the game isn't over and there hasn't been a timeout
			while(machine.gameStarted == false || (!bf.checkGameOver() && timeout_count < machine.timeout)){
				machine.processComBuffer();
				
				//starts the game
				if(machine.gameStarted == false && bf.getUnitsNumber() == (Dragon_N+MaxPlayer_N))
					machine.addCommand(new Command(CommandType.gameStart));
				
				//UPDATE
				//spawns the Units
				if(machine.gameStarted == false && bf.getUnitsNumber() < (Dragon_N + MaxPlayer_N)){
					//find a free spot
					do{
						x = (int)(Math.random()*bf.getWidth());
						y = (int)(Math.random()*bf.getHeight());
					}while(!bf.posFree(x, y));
					
					if(bf.getUnitsNumber() < Dragon_N){
						HP = (int)(Math.random() * (MAX_DHP - MIN_DHP) + MIN_DHP);
						AP = (int)(Math.random() * (MAX_DAP - MIN_DAP) + MIN_DAP);
						machine.addCommand(new Command(CommandType.spawn,HP,HP,AP,x,y,UnitType.dragon,machine.id));
					}
				}
				else
					timeout_count++;
				
				Thread.sleep(machine.genActionTs());
			}
			bf.printSurvivingUnits();
			//machine.writer.close();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	//add new client to list and send a copy of battlefield
	@Override
	public void register(String client_URL) {
		// TODO Auto-generated method stub
		this.Clients_URLs.add(client_URL);
	 	System.out.println(client_URL + " registered");
	 	
		try {
			Interface client = (Interface) java.rmi.Naming.lookup(client_URL);
			client.login(new Command(CommandType.trade,machine.battlefield.getMap()));
		} catch (MalformedURLException | NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//implemented on client only
	@Override
	public void login(Command c) {
		
	}
	
	//remove client from list
	@Override
	public void unregister(String client_URL) {
		// TODO Auto-generated method stub
		this.Clients_URLs.remove(client_URL);
	}

	//receive remote event
	@Override
	public void receiveMessage(Command c) {
		// TODO Auto-generated method stub
		machine.addCommand(c);
	}

	//send local event to all clients
	@Override
	public void sendMessage(Command c) throws RemoteException {
		// TODO Auto-generated method stub
		for (String url:Clients_URLs){
			try {
				Interface client = (Interface) java.rmi.Naming.lookup(url);
				client.receiveMessage(c);
			} catch (MalformedURLException | NotBoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
