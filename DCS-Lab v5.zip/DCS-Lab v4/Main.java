import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.rmi.AlreadyBoundException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

public class Main {
	//function to find out whether the simulation has stopped(false) or not(true)
	private static boolean SimulationRunning(ArrayList<Thread> t){
		//UPDATE
		for(int i=0; i<t.size(); i++)
			if(t.get(i).isAlive())
				return true;
		
		return false;
	}
	
	private static ArrayList<String> Servers_URLs = new ArrayList<String>();
	private static ArrayList<String> Clients_URLs = new ArrayList<String>();
	private static final int MAP_WIDTH = 25;
	private static final int MAP_HEIGHT = 25;
	private static final int Dragons_N = 1;
	private static final int MaxPlayer_N = 1;
	
	public static void main(String args[]) throws FileNotFoundException, UnsupportedEncodingException   {		
		int Servers_N = 1;			//Number of servers
		int Clients_N = 1;			//Number of Clients
		
		//check if map is large enough
		if((Dragons_N + MaxPlayer_N) > (MAP_WIDTH*MAP_HEIGHT)){
			System.out.println("ERROR: Map not large enough");
			return;
		}
		
		//adds the Servers URLs to the list
		for(int i=0; i < Servers_N; i++){
			Servers_URLs.add("rmi://localhost:" + (1099+i) + "/s" + i);
		}
		
		//adds the Clients URLs to the list
		for(int i=0; i < Servers_N; i++){
			Clients_URLs.add("rmi://localhost:" + (1099+Servers_N+i) + "/c" + i);
		}
		
		ArrayList<Thread> t = new ArrayList<Thread>();
		
		
		try {	
		//creates the servers
		ArrayList<Server> servers = new ArrayList<Server>();
		for(int i=0; i<Servers_N; i++){
			Machine machine = new Machine(i, MAP_WIDTH, MAP_HEIGHT, "server"+i+".res",Servers_URLs.get(i));
			servers.add(new Server(Servers_URLs, Dragons_N, MaxPlayer_N, machine,Servers_URLs.get(i)));
		}
		
		
		
		//creates the RMI registries
		ArrayList<Registry> reg = new ArrayList<Registry>();
		for(int i=0; i<(Servers_N + Clients_N); i++)
			reg.add( java.rmi.registry.LocateRegistry.createRegistry(1099+i));
		
		//binds a remote reference to the specified name in the registries
		for(int i=0; i<Servers_N; i++)
			reg.get(i).bind(Servers_URLs.get(i), servers.get(i));
		
		
		
		
		//binds the Servers URL to the servers
		for(int i=0; i<Servers_N; i++)
			java.rmi.Naming.bind(Servers_URLs.get(i), servers.get(i));
		
		
		//creates the clients
		ArrayList<Client> clients = new ArrayList<Client>();
		for(int i=0; i<Clients_N; i++) {
			//UPDATE
			int rand;
			Machine machine = new Machine(i, MAP_WIDTH, MAP_HEIGHT, "client"+i+".res",Clients_URLs.get(i));

			rand = (int) (Math.floor(Math.random()*Servers_N));
			clients.add(new Client(servers.get(rand) ,machine,Clients_URLs.get(i),MaxPlayer_N));
		}
			
				
		for(int i=0; i<Clients_N; i++)
			reg.get(i+Servers_N).bind(Clients_URLs.get(i), clients.get(i));
		
		
		//binds the Clients URL to the clients
		for(int i=0; i<Clients_N; i++)
			java.rmi.Naming.bind(Clients_URLs.get(i), clients.get(i));
	    
	    //creates the threads and starts them
		//UPDATE
		for(int i=0; i<Servers_N; i++){
			t.add(new Thread(servers.get(i)));
			t.get(i).start();
		}
		
		Thread.sleep(250);
		
		for(int i=0; i<Clients_N; i++){
			t.add(new Thread(clients.get(i)));
			t.get(i+Servers_N).start();
		}
	    
	    //waits for the simulation to end
		while(SimulationRunning(t)) {
	    	Thread.sleep(100);
		}
	    
	    //unbinds the registries references
		for(int i=0; i<Servers_N; i++)
	    	reg.get(i).unbind(Servers_URLs.get(i));
		for(int i=0; i<Clients_N; i++)
			reg.get(i+Servers_N).unbind(Clients_URLs.get(i));
		
		//unexports the registries
		for(int i=0; i<(Servers_N + Clients_N); i++)
			UnicastRemoteObject.unexportObject(reg.get(i),true);

		} catch ( RemoteException| MalformedURLException| 
				AlreadyBoundException | NotBoundException  
				| InterruptedException e) {
			e.printStackTrace();
		}
		//exits to kill the RMI ports
		System.exit(0);		
	}

}
