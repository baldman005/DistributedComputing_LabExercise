import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;

//Interface that enables processes to communicate
public interface Interface extends Remote {
	public void receiveMessage(Command c) throws RemoteException;

	public void register(String url) throws RemoteException;

	public void unregister(String url) throws RemoteException;

	public void sendMessage(Command c) throws RemoteException;
	
	public void login(Command c) throws RemoteException;
}
