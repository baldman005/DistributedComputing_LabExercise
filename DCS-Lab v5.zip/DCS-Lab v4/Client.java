import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.ThreadLocalRandom;

public class Client extends UnicastRemoteObject implements Interface, Runnable {
	private static final long serialVersionUID = 1L;
	
	//Immediate reference to RMI object
	private Server server;
	//stats about the Players units
	public final int MIN_PHP = 10;
	public final int MAX_PHP = 20;
	public final int MIN_PAP = 1;
	public final int MAX_PAP = 10;
	//machine that contains the client
	private Machine machine;
	//URL used for registering client to server
	private String client_URL;
	//number of Player units
	private int MaxPlayer_N;
	
	//constructor of Server
	protected Client( Server server, Machine machine,  String url, int MaxPlayer_N) throws RemoteException, FileNotFoundException, UnsupportedEncodingException {
		this.machine = machine;
		this.server = server;
		this.client_URL = url;
		this.MaxPlayer_N = MaxPlayer_N;
	}
	
	

	//runnable
	@Override
	public void run() {
		int HP, AP, x, y, timeout_count;
		Unit unit;
		//battlefield save machine
		Battlefield bf = machine.battlefield;
		
		
		server.register(client_URL);
		try {	
			timeout_count = 0;
			//runs while the game isn't over and there hasn't been a timeout
			while(machine.gameStarted == false || (!bf.checkGameOver() && timeout_count < machine.timeout)){
				machine.processComBuffer();
				
				//UPDATE
				//spawns the Units
				if(!machine.gameStarted && bf.getUnitsNumber() < MaxPlayer_N){

					
					do{
						x = (int)(Math.random()*bf.getWidth());
						y = (int)(Math.random()*bf.getHeight());
					}while(!bf.posFree(x, y));
					
					if(bf.getUnitsNumber() < MaxPlayer_N){	
						HP = (int)(Math.random() * (MAX_PHP - MIN_PHP) + MIN_PHP);
						AP = (int)(Math.random() * (MAX_PAP - MIN_PAP) + MIN_PAP);
						machine.addCommand(new Command(CommandType.spawn,HP,HP,AP,x,y,UnitType.player,machine.id));
						sendMessage(new Command(CommandType.spawn,HP,HP,AP,x,y,UnitType.player,machine.id));
					}
				}
				else
					timeout_count++;
				
				Thread.sleep(machine.genActionTs());
			}
			bf.printSurvivingUnits();
			//machine.writer.close();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	//send local event to server
	@Override
	public void sendMessage(Command c) {
		server.receiveMessage(c);
	}
	
	//receive remote event from server
	@Override
	public void receiveMessage(Command c) throws RemoteException {
		// TODO Auto-generated method stub
		machine.addCommand(c);
	}

	
	//implemented in server only
	@Override
	public void register(String url) throws RemoteException {
		// TODO Auto-generated method stub
		
	}

	//implemented in server only
	@Override
	public void unregister(String url) throws RemoteException {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void login(Command c) throws RemoteException {
		System.out.println(client_URL + " logged on");
		machine.battlefield.setMap(c.getMap());
	}
}
