import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.rmi.RemoteException;
import java.util.ArrayList;

//class machine that saves either the server or the client
public class Machine implements Serializable{
	private final int MAX_actionTs = 15;
	private final int MIN_actionTs = 5;
	public int id;
	public int timeout = 100000/MIN_actionTs;
	//buffer with commands;
	private ArrayList<Command> commands;
	//curr position in buffer
	private int command_pos = -1;
	public Battlefield battlefield;
	public boolean gameStarted = false;
	//arraylist with the units that the machine will process
	public ArrayList<Unit> my_units;
	//file to write results UPDATE
	//had to be commented because it is not Serializable which is needed for classes send over rmi messages
	//public PrintWriter writer;
	//RMI URL of client or server responsible for this machine
	public String owner;
	
	//constructor of Machine
	protected Machine(int id, int MAP_WIDTH, int MAP_HEIGHT, String filename, String owner) throws RemoteException, FileNotFoundException, UnsupportedEncodingException {
		this.id = id;
		battlefield = new Battlefield(MAP_WIDTH, MAP_HEIGHT,this);
		my_units = new ArrayList<Unit>();
		commands = new ArrayList<Command>();
		//writer = new PrintWriter(filename,"UTF-8");
		this.owner = owner;
	}
	
	//method to start threads to process units
	public void unitsStart(){
		for(Unit u:my_units)
			u.startProc();
	}
	
	//print to writer
	//public void writeFile(String message){
		//writer.println(message);
	//}
	
	//method to process the commands buffer
	public void processComBuffer(){
		Command c;
		Unit u;
		
		if((command_pos+1) < commands.size()){
			command_pos++;
			c = commands.get(command_pos);
			
			//ATTENTION, POSSIBLE BUG. For some reason, c can rarely come null. For now it ignores
			if(c==null){
				System.out.println(this.owner + ": " +"ERROR, command null");
				//writer.println("ERROR, command null");
				return;
			}
			u = c.processCommand(battlefield, id, this);
			//means that this server spawned the unit
			if(u != null){
				my_units.add(u);
				//if the game has already begun start processing the unit
				if(gameStarted)
					u.startProc();
			}
		}
	}
	
	//adds command to buffer
	public void addCommand(Command c){
		commands.add(c);
	}
	
	//starts the game
	public void startGame(){
		gameStarted = true;
		System.out.println(this.owner + ": " +"AND SO IT BEGINS...");
		//writer.println("AND SO IT BEGINS...");
		unitsStart();
	}
	
	//generate the action delay
	public int genActionTs(){
		return (int)(Math.random() * (MAX_actionTs - MIN_actionTs) + MIN_actionTs);
	}
}