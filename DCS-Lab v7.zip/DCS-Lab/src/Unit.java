import java.io.Serializable;

public class Unit implements Serializable{
	private static final long serialVersionUID = 1L;

	// Position of the unit
	private int x, y;

	// Health
	private int maxHP;
	private int HP;

	// Attack points
	private int AP;

	// Identifier of the unit
	private int unitID;
	
	// Unit Type
	private UnitType unittype;
	
	// Battlefield in which this unit is located
	private Battlefield bf;

	// Thread that processes the unit
	private Thread t;
	
	
	
	// Constructor
	protected Unit(int maxHP, int HP, int AP, int x, int y, int unitID, UnitType unittype, Battlefield bf){
		this.maxHP = maxHP;
		this.HP = HP;
		this.AP = AP;
		this.x = x; this.y = y;
		this.unitID = unitID;
		this.unittype = unittype;
		this.bf = bf;
	}
	
	//return maxHP
	public int getMaxHP(){
		return this.maxHP;
	}
	
	//return percentage of HP remaining
	public int getRemHP(){
		return ((HP*100)/maxHP);
	}
	
	//returns unit AP
	public int getAP(){
		return this.AP;
	}
		
	
	//return X position
	public int getX(){
		return this.x;
	}
	
	//return Y position
	public int getY(){
		return this.y;
	}
	
	//return unitID
	public int getUnitID(){
		return this.unitID;
	}
	
	//return HP
	public int getHP(){
		return this.HP;
	}
	
	//return unit type
	public UnitType getType(){
		return unittype;
	}
	
	public void setUnitID(int id) {
		this.unitID = id;
	}
	
	//calculate distance from other unit u
	public synchronized int calcDist(Unit u){
		return (Math.abs(u.x - x) + Math.abs(u.y - y));
	}
	
	
	/*update HP
	 returns 1 if Unit still lives, 0 if it dies
	 */
	public synchronized boolean updateUnitHP(int AP_SourceUnit){
		HP = HP + AP_SourceUnit;
		if (maxHP < HP) {
			HP = maxHP;
		}
		else if (HP <= 0){
			HP = 0;
			bf.getMachine().addStep(new Command(CommandType.remove,this.getX(),this.getY(),0,bf.getMachine().id),new Command(CommandType.spawn,this.getMaxHP(),this.getHP(),this.getAP(),this.getX(),this.getY(),this.getType(),bf.getMachine().id),null);
			System.out.println(bf.getMachine().owner + ": " +"UPDATE_HP: " + this.unittype + " unit "+ this.unitID + " now has " + this.HP + " HP" + "(" + this.getRemHP()+ "%)");
			bf.getMachine().addOutput("UPDATE_HP: " + this.unittype + " unit "+ this.unitID + " now has " + this.HP + " HP" + "(" + this.getRemHP()+ "%)");
			return true;
		}
		System.out.println(bf.getMachine().owner + ": " +"UPDATE_HP: " + this.unittype + " unit "+ this.unitID + " now has " + this.HP + " HP" + "(" + this.getRemHP()+ "%)");
		bf.getMachine().addOutput("UPDATE_HP: " + this.unittype + " unit "+ this.unitID + " now has " + this.HP + " HP" + "(" + this.getRemHP()+ "%)");
		return false;
	}
	

	//move unit
	public synchronized void moveUnit(int moveX, int moveY){
		int newX, newY;
		newX = this.x + moveX;
		newY = this.y + moveY;
		
		// check boundaries
		if (newX < 0)
			newX = 0;
		else if (newX >= bf.getWidth())
			newX = bf.getWidth()-1;
		if (newY < 0)
			newY = 0;
		else if (newY >= bf.getHeight())
			newY = bf.getHeight()-1;
		
		if(!bf.posFree(newX, newY))
			return;
		
		bf.moveUnitBf(this.x, this.y, newX, newY);
		this.x = newX;
		this.y = newY;	
		System.out.println(bf.getMachine().owner + ": " +this.unittype + " "+ this.unitID + " has MOVED to (" + this.x + "," +this.y +")");
		bf.getMachine().addOutput(this.unittype + " "+ this.unitID + " has MOVED to (" + this.x + "," +this.y +")");
	}
	
	//attack another unit
	public void attackUnit(Unit target){
		if(target.checkRunning()){
			System.out.println(bf.getMachine().owner + ": " +this.unittype+" "+this.unitID+" with AP "+this.AP+" ATTACKS "+target.unittype+" "+target.unitID+" with "+target.HP+ " HP (" + target.getRemHP()+ "%)");
			bf.getMachine().addOutput(this.unittype+" "+this.unitID+" with AP "+this.AP+" ATTACKS "+target.unittype+" "+target.unitID+" with "+target.HP+ " HP (" + target.getRemHP()+ "%)");
			target.updateUnitHP(-this.AP);
		}
	}
	
	//heal another unit
	public void healUnit(Unit target){
		if(target.checkRunning()){
			System.out.println(bf.getMachine().owner + ": " + this.unittype+" "+this.unitID+" with AP "+this.AP+" HEALS "+target.unittype+" "+target.unitID+" with "+target.HP + " HP (" + target.getRemHP()+ "%)");
			bf.getMachine().addOutput(this.unittype+" "+this.unitID+" with AP "+this.AP+" HEALS "+target.unittype+" "+target.unitID+" with "+target.HP + " HP (" + target.getRemHP()+ "%)");
			target.updateUnitHP(this.AP);
		}
	}
	
	//UPDATE
	//start thread to process the unit
	public synchronized void startProc(){
		switch(unittype){
			case dragon:
				t = new Thread(new Dragon(this, bf));
				t.start();
				break;
			case player:
				t = new Thread(new Player(this, bf));
				t.start();
				break;
			default:
				break;
		}
	}
	
	//check if it's running
	public boolean checkRunning(){
		if(this.HP > 0)
			return true;
		return false;
	}
}
