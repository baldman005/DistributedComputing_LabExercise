import java.io.Serializable;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;

public class Command implements Serializable {
	private static final long serialVersionUID = 1L;
	private CommandType type;
	private ArrayList<Integer> args_int;
	//send copy of map
	private ArrayList<Unit> units;
	
	//constructor for gameStart
	protected Command(CommandType type, int reply){
		this.type = type;
		args_int = new ArrayList<Integer>();
		args_int.add(reply);
	}
	
	//all Unit arguments had to be changed to their coordinates due to Unit running as Thread and Thread not Serializable
	//reply is just a flag to check if a command has to be send to client/server
	
	//constructor with unit to be removed (for remove)
	protected Command(CommandType type, int sourceX,int sourceY, int reply, int sender_id){
		this.type = type;
		args_int = new ArrayList<Integer>();
		args_int.add(sourceX);
		args_int.add(sourceY);
		args_int.add(reply);
		args_int.add(sender_id);
	}
	
	//constructor 1 value of coordinates, currHP, maxHP, AP, the unit type (0 dragon, 1 player)(for spawn), and the id of the client/server
	protected Command(CommandType type, int currHP, int maxHP, int AP, int x, int y, UnitType unittype, int sender_id){
		this.type = type;
		args_int = new ArrayList<Integer>();
		args_int.add(currHP);
		args_int.add(maxHP);
		args_int.add(AP);
		args_int.add(x);
		args_int.add(y);
		switch(unittype){
			case dragon:
				args_int.add(0);
				break;
			case player:
				args_int.add(1);
				break;
		}
		args_int.add(sender_id);
	}
	
	//constructor with only 2 values of coordinates(for attack, heal or move)
	protected Command(CommandType type, int sourceX, int sourceY,int  targetX, int targetY, int reply, int sender_id){
		this.type = type;
		args_int = new ArrayList<Integer>();
		args_int.add(sourceX);
		args_int.add(sourceY);
		args_int.add(targetX);
		args_int.add(targetY);
		args_int.add(reply);
		args_int.add(sender_id);
	}
	
	
	//constructor for sending an image of the battlefield map
	protected Command(CommandType type, ArrayList<Unit> units, int senderID) {
		this.type = type;
		this.units = units;
		args_int = new ArrayList<Integer>();
		args_int.add(senderID);
	}
	
	//return map of battlefield
	public ArrayList<Unit> getUnits(){
		return this.units;
	}
	
	//return command type
	public CommandType getType(){
		return type;
	}
	
	//return integer argument i
	public int arg(int i){
		if (i < args_int.size())
			return args_int.get(i);
		return -1;
	}
	
	//method to process a command
	public Unit processCommand(Battlefield battlefield, Machine machine){
		Unit new_unit = null;
		Unit source = null;
		Unit target = null;
				
		switch(this.getType()){
			case spawn:
				UnitType unittype;
				if(this.arg(5)==1)
					unittype = UnitType.player;
				else
					unittype = UnitType.dragon;
				
				new_unit = new Unit(this.arg(0),this.arg(1),this.arg(2),this.arg(3),this.arg(4),battlefield.getCurrID(),unittype,battlefield);
				battlefield.spawnUnit(new_unit);
				if(machine.id != this.arg(6))
					new_unit = null;
				//warn all clients if machine is server
				if(machine.id < machine.serversN){
					try {
						Interface dest = (Interface) java.rmi.Naming.lookup(machine.owner);
						dest.sendMessage(new Command(CommandType.spawn, this.arg(0),this.arg(1),this.arg(2),this.arg(3),this.arg(4),unittype,machine.id),new Command(CommandType.remove, this.arg(3),this.arg(4),0,machine.id),this.arg(6));
					} catch (RemoteException | MalformedURLException | NotBoundException e) {
						e.printStackTrace();
					}
				}
				break;
			case remove:
				source = battlefield.getUnit(this.arg(0), this.arg(1));
				battlefield.removeUnit(source);
				break;
			case attack:
				source = battlefield.getUnit(this.arg(0), this.arg(1));
				target = battlefield.getUnit(this.arg(2), this.arg(3));
				if(source.checkRunning()){
					source.attackUnit(target);
					if (this.arg(4) == 1 || machine.id < machine.serversN) {
						try {
							Interface dest = (Interface) java.rmi.Naming.lookup(machine.owner);
							dest.sendMessage(new Command(CommandType.attack, this.arg(0),this.arg(1),this.arg(2),this.arg(3),0, machine.id),new Command(CommandType.heal, this.arg(0),this.arg(1),this.arg(2),this.arg(3),0, machine.id),this.arg(5));
						} catch (RemoteException | MalformedURLException | NotBoundException e) {
							e.printStackTrace();
						}
					}
				}
				break;
			case heal:
				source = battlefield.getUnit(this.arg(0), this.arg(1));
				target = battlefield.getUnit(this.arg(2), this.arg(3));
				if(source.checkRunning()){
					source.healUnit(target);
					if (this.arg(4) == 1 || machine.id < machine.serversN) {
						try {
							Interface dest = (Interface) java.rmi.Naming.lookup(machine.owner);
							dest.sendMessage(new Command(CommandType.heal, this.arg(0),this.arg(1),this.arg(2),this.arg(3),0, machine.id),new Command(CommandType.attack, this.arg(0),this.arg(1),this.arg(2),this.arg(3),0, machine.id),this.arg(5));
						} catch (RemoteException | MalformedURLException | NotBoundException e) {
							e.printStackTrace();
						}
					}
				}
				break;
			case move:
				//System.out.println(this.arg(0)+","+this.arg(1));
				source = battlefield.getUnit(this.arg(0),this.arg(1));
				source.moveUnit(this.arg(2),this.arg(3));
				if (this.arg(4) == 1 || machine.id < machine.serversN) {
					try {
						Interface dest = (Interface) java.rmi.Naming.lookup(machine.owner);
						dest.sendMessage(new Command(CommandType.move, this.arg(0),this.arg(1),this.arg(2),this.arg(3),0,machine.id),new Command(CommandType.move, this.arg(0)+this.arg(2),this.arg(1)+this.arg(3),-this.arg(2),-this.arg(3),0,machine.id),this.arg(5));
					} catch (RemoteException | MalformedURLException | NotBoundException e) {
						e.printStackTrace();
					}
				}
				break;
			case gameStart:
				machine.startGame();
				//Here it's not necessary to check if a server received because only the server can start a game
				if (this.arg(0) == 1) {
					try {
						Interface dest = (Interface) java.rmi.Naming.lookup(machine.owner);
						dest.sendMessage(new Command(CommandType.gameStart, 0),null,-1);
					} catch (RemoteException | MalformedURLException | NotBoundException e) {
						e.printStackTrace();
					}
				}
				break;
			default:
				break;
		}
		
		return new_unit;
	}
}