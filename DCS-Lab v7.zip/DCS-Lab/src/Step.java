import java.io.Serializable;
import java.sql.Timestamp;

public class Step implements Serializable{
	private static final long serialVersionUID = 1L;
	private Command normal;
	private Command inverse;
	private Timestamp timestamp;
	
	protected Step(Command normal, Command inverse, Timestamp timestamp){
		this.normal = normal;
		this.inverse = inverse;
		this.timestamp = timestamp;
	}
	
	public Command getNormalCommand(){
		return normal;
	}
	
	public Command getInvCommand(){
		return inverse;
	}
	
	public Timestamp getTimestamp() {
		return timestamp;
	}
}
