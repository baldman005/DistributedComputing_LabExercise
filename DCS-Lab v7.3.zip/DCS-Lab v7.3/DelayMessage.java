import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class DelayMessage implements Runnable {

	private String URL;	//URL of the receiver process
	private Step s;	//Message that is going to be sent
	private static final int MIN_DELAY = 2;
	private static final int MAX_DELAY = 100;
		
	//constructor of the object Delay_Message_Thread
	public DelayMessage(Step s, String URL) {
		this.URL=URL;
		this.s=s;
		return;
	}
	
	//runnable 
	@Override
	public void run () {		
		Interface receiver;
		/*
		 * Simulates a random delay, with Thread.sleep, and the receiver 
		 * receives the message using method receive_ack in the interface 
		 */
		try {
			int delay = (int)(Math.random() *(MAX_DELAY - MIN_DELAY) + MIN_DELAY);
			Thread.sleep(delay);
			receiver = (Interface) java.rmi.Naming.lookup(URL);
			receiver.receiveMessage(s);
		} catch (MalformedURLException | RemoteException | NotBoundException | InterruptedException e) {
			e.printStackTrace();
		}

		return;
	}

}