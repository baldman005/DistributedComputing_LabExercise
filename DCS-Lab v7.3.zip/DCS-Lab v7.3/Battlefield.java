import java.io.Serializable;
import java.util.ArrayList;

//class that contains the battlefield
public class Battlefield implements Serializable{
	private static final long serialVersionUID = 1L;
	private int MAP_WIDTH, MAP_HEIGHT;
	private Unit[][] map;
	private ArrayList<Unit> units;
	// ID of next unit that spawns, somehow that gets transmitted
	private int currID;
	//boolean to known whether the game has ended or not
	private boolean gameOver = false;
	//machine(server/client) connected to battlefield 
	private Machine machine;
	
	//constructor
	protected Battlefield(int width, int height,Machine machine) {		
		map = new Unit[width][height];
		units = new ArrayList<Unit>();
		currID = 0;
		MAP_WIDTH = width;
		MAP_HEIGHT = height;
		this.machine = machine;
	}
	
	//returns map of battlefield
	public ArrayList<Unit> getUnits(){
		return this.units;
	}
	
	//changes the map of the battlefield
	public void setUnits(ArrayList<Unit> units, int units_owner_id) {
		units = new ArrayList<Unit>(units);
		for(Unit u:units)
			if (map[u.getX()][u.getY()]==null) {
				machine.addStep(new Command(CommandType.spawn, CommandType.normal,u.getMaxHP(),u.getHP(),u.getAP(),u.getX(),u.getY(),u.getType(),units_owner_id),new Command(CommandType.remove, CommandType.inv, u.getX(),u.getY(),0,units_owner_id),null);
			}
			else {
				map[u.getX()][u.getY()].setUnitID(u.getUnitID());
			}
	}
	
	//return machine
	public Machine getMachine(){
		return machine;
	}
	
	//spawns a unit in the battlefield
	public synchronized int spawnUnit(Unit unit){
		if(map[unit.getX()][unit.getY()] == null){
			System.out.println(machine.owner + ": " + unit.getType() + " "+ unit.getUnitID() + " has SPAWNED in position (" + unit.getX() + "," + unit.getY()+"); HP: "+unit.getHP()+" AP: "+unit.getAP());
			machine.addOutput(unit.getType() + " "+ unit.getUnitID() + " has SPAWNED in position (" + unit.getX() + "," + unit.getY()+"); HP: "+unit.getHP()+" AP: "+unit.getAP());
			
			map[unit.getX()][unit.getY()] = unit;
			units.add(unit);
			//update current id
			if(unit.getUnitID() >=  currID){
				currID = unit.getUnitID()+1;
			}
			
			return unit.getUnitID();
		}
		else
			return -1;
	}
	
	//check if a faction won or if there has been a draw. If yes then return true
	public synchronized boolean VicOrDraw(){
		if(units.size() < 2)
			return true;
		for(int i=1; i<units.size(); i++)
			if(units.get(i-1).getType() != units.get(i).getType())
				return false;
		return true;
	}
		
	//removes a unit from the battlefield
	public synchronized void removeUnit(Unit unit, boolean check_end){
		if(unit == null)
			return;
		
		map[unit.getX()][unit.getY()] = null;
		units.remove(unit);
		
		System.out.println(machine.owner + ": " + unit.getType() + " "+ unit.getUnitID() + " has been REMOVED");
		machine.addOutput(unit.getType() + " "+ unit.getUnitID() + " has been REMOVED");
		
		if(check_end && this.VicOrDraw())
			gameOver = true;
	}
	
	//finds nearest unit of type UnitType in battlefield
	public synchronized Unit getNearestUnitType(Unit source, UnitType type){
		int dist, minDist = 10000; //initial minimum distance found is infinite
		Unit closest = null;
			
		for(Unit u:units){
			if(u.getType()!=type)
				continue;
			
			dist = source.calcDist(u);
			//u is equal to source unit
			if(dist == 0)
				continue;
			else if(dist < minDist){
				minDist = dist;
				closest = u;
			}
		}
		return closest;
	}
	
	//moves unit in the battlefield
	public synchronized void moveUnitBf(int old_x, int old_y, int new_x, int new_y){
		map[new_x][new_y] = map[old_x][old_y];
		map[old_x][old_y] = null;
	}
	
	//returns MAP_WIDTH
	public int getWidth(){
		return MAP_WIDTH;
	}
	
	//returns MAP_HEIGHT
	public int getHeight(){
		return MAP_HEIGHT;
	}
	
	//returns unit at position (x,y)
	public synchronized Unit getUnit(int x, int y){
		return map[x][y];
	}
	
	//return the currID
	public synchronized int getCurrID(){
		return currID;
	}
	
	//returns the boolean gameOver
	public boolean checkGameOver(){
		return gameOver;
	}
	
	//returns the number of units
	public int getUnitsNumber(){
		return units.size();
	}
	
	//checks if position is occupied or not
	public synchronized boolean posFree(int x,int y){
		if(map[x][y] == null)
			return true;
		return false;
	}
		
	
	//method to print the surviving units
	public void printSurvivingUnits(){
		System.out.println(machine.owner + ": " +"GAME OVER");
		machine.addOutput("GAME OVER");
		if(units.size() == 0){
			System.out.println(machine.owner + ": " +"DRAW, revenge has consumed them ");
			machine.addOutput("DRAW, revenge has consumed them ");
		}
		else if(VicOrDraw())
			if(units.get(0).getType() == UnitType.dragon){
				System.out.println(machine.owner + ": " +"DRAGONS continue to rule the Silence Fields");
				machine.addOutput("DRAGONS continue to rule the Silence Fields");;
			}
			else{
				System.out.println(machine.owner + ": " +"KNIGHTS have brought justice to the Silence Fields");
				machine.addOutput("KNIGHTS have brought justice to the Silence Fields");
			}
		else{
			System.out.println(machine.owner + ": " +"TIMEOUT");
			machine.addOutput("TIMEOUT");
		}
		System.out.println(machine.owner + ": " +"Surviving units:");
		machine.addOutput("Surviving units:");
		for(Unit u:units){
			System.out.println(machine.owner + ": " +u.getType()+" unit "+u.getUnitID()+"; pos: ("+u.getX()+","+u.getY()+"); HP: "+u.getHP()+"("+u.getRemHP()+"%)");
			machine.addOutput(u.getType()+" unit "+u.getUnitID()+"; pos: ("+u.getX()+","+u.getY()+"); HP: "+u.getHP()+"("+u.getRemHP()+"%)");
		}
		machine.addOutput("END");
	}
		
}
