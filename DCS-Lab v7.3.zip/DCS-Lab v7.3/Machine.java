import java.io.FileNotFoundException;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;

//class machine that saves either the server or the client
public class Machine implements Serializable{
	private static final long serialVersionUID = 1L;
	public final int MAX_actionTs = 15;
	public final int MIN_actionTs = 5;
	public int id;
	public int timeout = 10000/MIN_actionTs;
	//buffer with commands;
	private ArrayList<Step> steps;
	//curr position in buffer
	private int step_pos = -1;
	private int max_commands = 50;
	public Battlefield battlefield;
	public boolean gameStarted = false;
	//arraylist with the units that the machine will process
	public ArrayList<Unit> my_units;
	//RMI URL of client or server responsible for this machine
	public String owner;
	//buffer with the messages for the file
	public ArrayList<String> outputs;
	private int outputs_pos = -1;
	private int max_outputs = 50;
	//to distinguish ids from servers and clients, saves the number of servers and clients
	public int serversN;
	//the timestamp of the current command
	public Timestamp timestamp;
	//the milliseconds needed to determine the time to add to each new Timestamp
	public int timeDiff;
	
	//constructor of Machine
	protected Machine(int id, int MAP_WIDTH, int MAP_HEIGHT, String owner, int serversN) throws RemoteException, FileNotFoundException, UnsupportedEncodingException {
		this.id = id;
		battlefield = new Battlefield(MAP_WIDTH, MAP_HEIGHT,this);
		my_units = new ArrayList<Unit>();
		steps = new ArrayList<Step>();
		this.owner = owner;
		outputs = new ArrayList<String>();
		this.serversN = serversN;
		this.timestamp = new Timestamp(System.currentTimeMillis());
	}
	
	
	//get a new Timestamp
	public Timestamp getTimestamp() {
		return new Timestamp(System.currentTimeMillis());
	}
	
	//set the Timestamp, used afte adding each command
	public void setTimestamp(Timestamp t){
		this.timestamp = t;
	}
	
	//set the time between timestamps
	public void setTimeDiff(int initialTime){
		this.timeDiff = initialTime;
	}
	
	//method to start threads to process units
	public void unitsStart(){
		for(Unit u:my_units)
			u.startProc();
	}
	
	//method to add string to outputs
	public void addOutput(String message){
		if(outputs.size() == max_outputs){
			outputs.remove(0);
			outputs_pos--;
		}
		outputs.add(message);
	}
	
	//method to return an output
	public String getOutput(){
		String out = null;
		
		if((outputs_pos+1) < outputs.size()){
			outputs_pos++;
			out = outputs.get(outputs_pos);
		}
		return out;
	}
	
	//method to process the steps buffer
	public void processStepBuffer(){
		Step s;
		Unit u;
				
		if((step_pos+1) < steps.size()){
			step_pos++;
			s = steps.get(step_pos);
			
			//ATTENTION, POSSIBLE BUG. For some reason, c can rarely come null. For now it ignores
			if(s==null){
				System.out.println(this.owner + ": " +"ERROR, command null");
				this.addOutput("ERROR, command null");
				return;
			}
			u = s.getNormalCommand().processCommand(battlefield, this, gameStarted);
			//means that this server spawned the unit
			if(u != null){
				my_units.add(u);
				//if the game has already begun start processing the unit
				if(gameStarted)
					u.startProc();
			}
		}
	}
	
	//adds step to buffer
	public void addStep(Command normal, Command inverse, Timestamp timestamp){
		//if buffer is full discard oldest command
		if(steps.size() == max_commands){
			steps.remove(0);
			step_pos--;
		}
		//If the command is added by this Thread, create a new timestamp for it
		//https://stackoverflow.com/questions/30459417/how-to-add-milliseconds-to-the-timestamp-to-get-the-next-time
		if (timestamp == null){
		 	 Calendar cal = Calendar.getInstance();
		 	 cal.setTimeInMillis(this.timestamp.getTime());
		 	 cal.add(Calendar.MILLISECOND, (int) (System.currentTimeMillis() - timeDiff));
		 	 Timestamp newTimestamp = new Timestamp(cal.getTime().getTime());
		 	 setTimeDiff((int)System.currentTimeMillis());
		 	 setTimestamp(newTimestamp);
		 	 steps.add(new Step(normal,inverse,newTimestamp));
		 } else {
			 steps.add(new Step(normal,inverse,timestamp));
		 }
	}
	
	//starts the game
	public void startGame(){
		System.out.println(this.owner + ": " +"Battle begins");
		this.addOutput("Battle begins");
		gameStarted = true;
		unitsStart();
	}
	
	//generate the action delay
	public int genActionTs(){
		return (int)(Math.random() * (MAX_actionTs - MIN_actionTs) + MIN_actionTs);
	}
	
	public void checkTimestamp(Step s) {
		Timestamp timestamp = s.getTimestamp();
		int inverse_index = 0;
		//iterate through the step list and find if the received step was delayed
		for (int i=0; i<steps.size(); i++) {
			Step step = steps.get(i);
			
			Timestamp temp = step.getTimestamp();
			//check if the list should change
			if (timestamp.before(temp)) {
				inverse_index = i;
				System.out.println(this.owner + ": " +"Rollback and fix state");
				this.addOutput("Rollback and fix state");
				fixSteps(inverse_index);
				System.out.println(this.owner + ": End Rollback");
				this.addOutput("End Rollback");
				break;
			}
		}
	}
	
	public void fixSteps(int inverse_index) {
		//iterate the list in reverse and execute inverse commands
		for (int i=steps.size()-1;i >= inverse_index;i--) {
			Step step = steps.get(i);
			Command c = step.getInvCommand();
			
			if(c == null)
				return;

			Unit u = step.getInvCommand().processCommand(battlefield, this, gameStarted);
			if(u != null){
				my_units.add(u);
				//if the game has already begun start processing the unit
				if(gameStarted)
					u.startProc();
			}
		}

		//sort updated list
		Collections.sort(steps, new Comparator<Step>() {
		    @Override
		    public int compare(Step s1, Step s2) {
		        if (s2.getTimestamp().before(s1.getTimestamp()))
		            return 1;
		        else if(s2.getNormalCommand().getSenderId() < s1.getNormalCommand().getSenderId())
		        	return 1;
		        return -1;
		    }
		});
		
		//execute normal commands for the part of the list that changed
		for (int i=inverse_index;i < steps.size();i++) {
			Step step = steps.get(i);
			Unit u = step.getNormalCommand().processCommand(battlefield, this, gameStarted);
			if(u != null){
				my_units.add(u);
				//if the game has already begun start processing the unit
				if(gameStarted)
					u.startProc();
			}
		}
	}
}