//Types of commands
public enum CommandType{
	spawn,remove,attack,heal,move,gameStart,trade,updateID,normal,inv
};