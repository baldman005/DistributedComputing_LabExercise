import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.ThreadLocalRandom;

public class Client extends UnicastRemoteObject implements Runnable {
	private static int id;
	private static int MAP_WIDTH, MAP_HEIGHT;
	private static ArrayList<String> Servers_URLs;
	//ADD BATTLEFIELD
	
	//constructor of Server
	protected Client(int id, ArrayList<String> Servers_URLs, int MAP_WIDTH, int MAP_HEIGHT) throws RemoteException, FileNotFoundException, UnsupportedEncodingException {
		Client.id = id;
		Client.MAP_WIDTH = MAP_WIDTH;
		Client.MAP_HEIGHT = MAP_HEIGHT;
		Client.Servers_URLs = new ArrayList<String>(Servers_URLs); 
	}

	//runnable
	@Override
	public void run() {
		
	}
}
