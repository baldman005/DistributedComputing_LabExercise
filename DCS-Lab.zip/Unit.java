public class Unit{
	// Position of the unit
	private int x, y;

	// Health
	private int maxHP;
	private int HP;

	// Attack points
	private int AP;

	// Identifier of the unit
	private int unitID;
	
	// Unit Type
	private UnitType unittype;
	
	//boolean to check if it's running
	private boolean running;
	
	// Possible directions
	public enum Direction{
		up, down, left, right,
	};
	
	// Battlefield in which this unit is located
	private Battlefield bf;

	// Thread that processes the unit
	private Thread t;
	
	// Constructor
	protected Unit(int maxHP, int AP, int x, int y, int unitID, UnitType unittype, Battlefield bf){
		this.maxHP = maxHP;
		this.HP = maxHP;	//starts with full HP
		this.AP = AP;
		this.x = x; this.y = y;
		this.unitID = unitID;
		this.unittype = unittype;
		this.running = true;
		this.bf = bf;
	}
	
	//return X position
	public int getX(){
		return this.x;
	}
	
	//return Y position
	public int getY(){
		return this.y;
	}
	
	//return unitID
	public int getUnitID(){
		return this.unitID;
	}
	
	//return HP
	public int getHP(){
		return this.HP;
	}
	
	//return unit type
	public UnitType getType(){
		return unittype;
	}
	
	/*update HP
	 returns 1 if Unit still lives, 0 if it dies
	 */
	public synchronized boolean updateUnitHP(int AP_SourceUnit){
		HP = HP + AP_SourceUnit;
		if (maxHP < HP)
			HP = maxHP;
		else if (HP < 0){
			HP = 0;
			System.out.println(this.unittype + " unit "+ this.unitID + " now has " + this.HP + " HP");
			return true;
		}
		System.out.println(this.unittype + " unit "+ this.unitID + " now has " + this.HP + " HP");
		return false;
	}
	
	//move unit
	public synchronized void moveUnit(Direction d, int MAP_WIDTH, int MAP_HEIGHT){
		int newX, newY;
		int moveX = 0, moveY = 0;
		
		switch(d){
			case up:
				moveY = 1;
				break;
			case down:
				moveY = -1;
				break;
			case left:
				moveX = -1;
				break;
			case right:
				moveX = 1;
				break;
		}
		
		newX = this.x + moveX;
		newY = this.y + moveY;
		
		// check boundaries
		if (newX < 0)
			newX = 0;
		else if (newX >= MAP_WIDTH)
			newX = MAP_WIDTH-1;
		if (newY < 0)
			newY = 0;
		else if (newY >= MAP_HEIGHT)
			newY = MAP_HEIGHT-1;
		
		//check if new position is occupied or unit didn't move (tried to move to wall)
		if(bf.getUnit(newX, newY) != null || (this.x == newX && this.y == newY))
			return;
		
		bf.moveUnit(this.x, this.y, newX, newY);
		this.x = newX;
		this.y = newY;
		System.out.println(this.unittype + " unit "+ this.unitID + " now has moved to (" + this.x + "," +this.y +")");

		
	}
	
	//attack another unit
	public void attackUnit(Unit target){
		boolean death;
		
		System.out.println(this.unittype+" unit "+this.unitID+" with AP "+this.AP+" attacks "+target.unittype+" unit "+target.unitID+" with HP "+target.HP );
		death = target.updateUnitHP(-this.AP);
		if(death)
			bf.removeUnit(target);
	}
	
	//heal another unit
	public void healUnit(Unit target){
		System.out.println(this.unittype+" unit "+this.unitID+" with AP "+this.AP+" heals "+target.unittype+" unit "+target.unitID+" with HP "+target.HP );
		target.updateUnitHP(this.AP);
	}
	
	//UPDATE
	//start thread to process the unit
	public synchronized void startProc(){
		switch(unittype){
			case dragon:
				t = new Thread(new Dragon(this, bf));
				t.start();
				break;
			case player:
				t = new Thread(new Player(this, bf));
				t.start();
				break;
			default:
				break;
		}
	}
	
	//check if it's running
	public boolean checkRunning(){
		return running;
	}
	
	//disconnect the unit
	public void disconnect(){
		running = false;
	}
}
