//Class that has runnable that processes Dragon Unit
public class Dragon implements Runnable{
	//Dragon unit
	private Unit unit;
	//Battlefield
	private static Battlefield bf;
	//Delay between actions
	private static final int delay = 50;
	//Attack range
	private static final int attackDist = 2;
	
	//Constructor
	public Dragon(Unit unit, Battlefield bf){
		this.unit = unit;
		Dragon.bf = bf;
	}
	
	//Returns the unit at distance (x,y) from the Dragon
	private static synchronized Unit getNearUnit(int DragonX, int DragonY, int x, int y){
		int TargetX, TargetY;
		int MAP_WIDTH, MAP_HEIGHT;

		MAP_WIDTH = bf.getWidth();
		MAP_HEIGHT = bf.getHeight();
		
		TargetX = DragonX + x;
		TargetY = DragonY + y;
								
		if(TargetX<0 || TargetX>=MAP_WIDTH || TargetY<0 || TargetY>=MAP_HEIGHT)
			return null;
		return (bf.getUnit(TargetX, TargetY));
	}
	
	//Checks if Dragon has any target of type TargetType in range and returns it
	private Unit findTarget(int dist, UnitType TargetType){
		int DragonX, DragonY;
		int x, y, xtarget, ytarget;
		int begin, dir;
		Unit Target = null;
		
		DragonX = unit.getX(); 
		DragonY = unit.getY();
		
		//algorithm to find target
		for(int i=1; i<=dist; i++){
			begin = (int)((Math.random())*3);
			dir = (int)((Math.random())*2);
			
			switch(begin){
				case(0):
					x = -i; y = 0;
					break;
				case(1):
					x = 0; y = i;
					break;
				case(2):
					x = i; y = 0;
					break;
				case(3):
					x = 0; y = -i;
					break;
				default:
					x = 0; y = 0; 
			}
			switch(dir){
			case(0):
				dir = -1;
				break;
			case(1):
				dir = 1;
				break;
			}
			
			for(int j=0; j < 4; j++){
				xtarget = y; ytarget = x;
				if(xtarget != 0)
					xtarget = xtarget*(int)dir;
				else
					ytarget = ytarget*(int)dir;
				
				do{
					Target = Dragon.getNearUnit(DragonX, DragonY, x, y);
					if(Target != null && Target.getType() == TargetType)
						return Target;
					x = x + Integer.signum(xtarget-x);
					y = y + Integer.signum(ytarget-y);
				}while(x != xtarget || y != ytarget);
				dir = -dir;
			}
		}	
		return null;
	}
	
	//runnable
	@Override
	public void run() {
		Unit Target;
				
		try{
		while(unit.checkRunning()){
			//find prey
			Target = findTarget(attackDist,UnitType.player);
			if(Target != null){
				unit.attackUnit(Target);
			}
			
			Thread.sleep(delay);
		}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}