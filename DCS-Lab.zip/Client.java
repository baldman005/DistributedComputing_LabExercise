import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.ThreadLocalRandom;

public class Client extends UnicastRemoteObject implements Runnable {
	private static int id;
	private static int MAP_WIDTH, MAP_HEIGHT;
	private static ArrayList<String> Servers_URLs;
	private Server server;
	private int Player_N;
	//ADD BATTLEFIELD
	public final int MIN_HP = 10;
	public final int MAX_HP = 20;
	public final int MIN_AP = 1;
	public final int MAX_AP = 10;
	
	//constructor of Server
	protected Client(int id, ArrayList<String> Servers_URLs, int MAP_WIDTH, int MAP_HEIGHT, int Player_N, Server server) throws RemoteException, FileNotFoundException, UnsupportedEncodingException {
		this.Player_N = Player_N;
		this.id = id;
		this.Servers_URLs = new ArrayList<String>(Servers_URLs);
		this.server = server;
	}

	//runnable
	@Override
	public void run() {
		int HP, AP, id, count, timeout = 20;
		Unit unit;
		
		Battlefield bf = server.getBf();
		
		//spawns the Players and starts threads to process them
		for(int i=0; i<Player_N; i++){
			HP = (int)(Math.random() * (MAX_HP - MIN_HP) + MIN_HP);
			AP = (int)(Math.random() * (MAX_AP - MIN_AP) + MIN_AP);
			id = bf.getCurrID();
			unit = new Unit(HP,AP,i,i,id,UnitType.player,bf);
			bf.spawnUnit(unit);
			unit.startProc();
		}
		
		try {
			count = 0;
			//runs while the game isn't over and there hasn't been a timeout
			while(!bf.checkGameOver() && count < timeout){
				Thread.sleep(250);
				count++;
			}
			bf.printSurvivingUnits();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
