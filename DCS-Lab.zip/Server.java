import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

//class Server
public class Server extends UnicastRemoteObject implements Runnable {
	private int id;
	private ArrayList<String> Servers_URLs;
	private ArrayList<String> Clients_URLs;
	private Battlefield battlefield;
	private int Dragon_N;
	//stats about the Dragon units
	public final int MIN_HP = 50;
	public final int MAX_HP = 100;
	public final int MIN_AP = 5;
	public final int MAX_AP = 20;
	
	//constructor of Server
	protected Server(int id, ArrayList<String> Servers_URLs, int MAP_WIDTH, int MAP_HEIGHT, int Dragon_N, Battlefield bf) throws RemoteException, FileNotFoundException, UnsupportedEncodingException {
		this.id = id;
		this.Servers_URLs = new ArrayList<String>(Servers_URLs);
		this.Dragon_N = Dragon_N;
		Clients_URLs = new ArrayList<String>();
		battlefield = bf;
	}

	public Battlefield getBf() {
		return this.battlefield;
	}
	
	//runnable
	@Override
	public void run() {
		int HP, AP, id, count, timeout = 20;
		Unit unit;
		
		//UPDATE
		//spawns the Dragons and starts threads to process them
		for(int i=0; i<Dragon_N; i++){
			HP = (int)(Math.random() * (MAX_HP - MIN_HP) + MIN_HP);
			AP = (int)(Math.random() * (MAX_AP - MIN_AP) + MIN_AP);
			id = battlefield.getCurrID();
			unit = new Unit(HP,AP,i,i,id,UnitType.dragon,battlefield);
			battlefield.spawnUnit(unit);
			unit.startProc();
		}
		
		try {
			count = 0;
			//runs while the game isn't over and there hasn't been a timeout
			while(!battlefield.checkGameOver() && count < timeout){
				Thread.sleep(250);
				count++;
			}
			battlefield.printSurvivingUnits();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
