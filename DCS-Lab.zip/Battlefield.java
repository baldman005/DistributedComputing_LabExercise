import java.util.ArrayList;

//class that contains the battlefield
public class Battlefield {
	private static int MAP_WIDTH, MAP_HEIGHT;
	private Unit[][] map;
	private ArrayList<Unit> units;
	// ID of next unit that spawns
	private static int currID;
	//boolean to known whether the game has ended or not
	private static boolean gameOver = false;
	
	//constructor
	protected Battlefield(int width, int height) {		
		map = new Unit[width][height];
		units = new ArrayList<Unit>();
		currID = 0;
		MAP_WIDTH = width;
		MAP_HEIGHT = height;
	}
	
	
	//spawns a unit in the battlefield
	public synchronized boolean spawnUnit(Unit unit){
		if(map[unit.getX()][unit.getY()] == null){
			map[unit.getX()][unit.getY()] = unit;
			units.add(unit);
			if(unit.getUnitID() >=  currID){
				currID = unit.getUnitID()+1;
			}
			
			System.out.println(unit.getType() + " unit "+ unit.getUnitID() + " has spawned in position (" + unit.getX() + "," + unit.getY()+")");
			
			return true;
		}
		else
			return false;
	}
	
	//removes a unit from the battlefield
	public synchronized void removeUnit(Unit unit){
		map[unit.getX()][unit.getY()] = null;
		unit.disconnect();
		units.remove(unit);

		System.out.println(unit.getType() + " unit "+ unit.getUnitID() + " has been removed");
		
		//UPDATE
		if(units.size() == 1){
			//all die
			if(units.get(0).getHP() == 0)
				units.remove(units.get(0));
			gameOver = true;
		}
	}
	
	//moves unit in the battlefield
	public synchronized void moveUnit(int old_x, int old_y, int new_x, int new_y){
		map[new_x][new_y] = map[old_x][old_y];
		map[old_x][old_y] = null;
	}
	
	//returns MAP_WIDTH
	public int getWidth(){
		return MAP_WIDTH;
	}
	
	//returns MAP_HEIGHT
	public int getHeight(){
		return MAP_HEIGHT;
	}
	
	//returns unit at position (x,y)
	public synchronized Unit getUnit(int x, int y){
		return map[x][y];
	}
	
	//return the currID
	public synchronized int getCurrID(){
		return currID;
	}
	
	//returns the boolean gameOver
	public boolean checkGameOver(){
		return gameOver;
	}
	
	//method to print the surviving units
	public void printSurvivingUnits(){
		System.out.println("GAME OVER");
		System.out.println("SURVIVING UNITS");
		for(Unit u:units)
			System.out.println(u.getType()+" unit "+u.getUnitID()+"; pos: ("+u.getX()+","+u.getY()+"); HP: "+u.getHP());
	}
}
